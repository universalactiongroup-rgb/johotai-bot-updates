﻿Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
$ErrorActionPreference = 'Stop'
$script:Base = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $script:Base
$script:BotProcess = $null
$script:TunnelProcess = $null
$script:QuickTunnelMode = $false
$script:QuickTunnelReadyShown = $false
$script:QuickTunnelOut = Join-Path $script:Base 'cloudflared-output.log'
$script:QuickTunnelError = Join-Path $script:Base 'cloudflared-error.log'
$script:LogPath = Join-Path $script:Base 'bot-output.log'
$script:ErrorLogPath = Join-Path $script:Base 'startup-error.log'
$script:Version = '4.1.2'
$script:LastStatsStatusStamp = $null
$script:MigrationMessage = $null
$script:AllMembers = @()

function Restore-LegacyDatabase {
  $current = Join-Path $script:Base 'data\database.json'
  if (Test-Path $current) { return }
  $parent = Split-Path $script:Base -Parent
  $candidates = @()
  foreach ($folder in @(Get-ChildItem $parent -Directory -ErrorAction SilentlyContinue | Where-Object { $_.FullName -ne $script:Base -and $_.Name -match '(?i)(Johotai|Case.Bot|Security.Management|情報保安)' })) {
    $direct = Join-Path $folder.FullName 'data\database.json'
    if (Test-Path $direct) { $candidates += Get-Item $direct }
    foreach ($child in @(Get-ChildItem $folder.FullName -Directory -ErrorAction SilentlyContinue)) {
      $nested = Join-Path $child.FullName 'data\database.json'
      if (Test-Path $nested) { $candidates += Get-Item $nested }
    }
  }
  $source = $candidates | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $source) { return }
  try {
    $test = Get-Content $source.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $test.guilds) { return }
    New-Item (Split-Path $current -Parent) -ItemType Directory -Force | Out-Null
    Copy-Item $source.FullName $current -Force
    $script:MigrationMessage = "旧版の会員データを自動引継ぎしました：$($source.Directory.Parent.Name)"
  } catch { }
}

function Read-EnvFile {
  $result = @{}
  $path = Join-Path $script:Base 'config.env'
  if (Test-Path $path) {
    Get-Content $path -Encoding UTF8 | ForEach-Object {
      if ($_ -match '^\s*([^#=]+)=(.*)$') { $result[$matches[1].Trim()] = $matches[2].Trim() }
    }
  }
  return $result
}
function Save-Config {
  $token = $TokenBox.Password.Trim()
  $guild = $GuildBox.Text.Trim()
  $prefix = $PrefixBox.Text.Trim()
  $color = $ColorBox.Text.Trim()
  $updateUrl = $UpdateBox.Text.Trim()
  $clientSecret = $ClientSecretBox.Password.Trim()
  $activityUrl = $ActivityUrlBox.Text.Trim()
  $tunnelToken = $TunnelTokenBox.Password.Trim()
  $presenceIntent = if ($PresenceCheck.IsChecked) { 'true' } else { 'false' }
  $existing = Read-EnvFile
  $emergencyKey = $EmergencyKeyBox.Password.Trim()
  if ([string]::IsNullOrWhiteSpace($emergencyKey)) { $emergencyKey = $existing.EMERGENCY_DATA_KEY }
  if ([string]::IsNullOrWhiteSpace($prefix)) { $prefix = 'JHT' }
  if ([string]::IsNullOrWhiteSpace($color)) { $color = '00BCD4' }
  $content = "DISCORD_BOT_TOKEN=$token`r`nDISCORD_GUILD_ID=$guild`r`nCASE_PREFIX=$prefix`r`nEMBED_COLOR=$color`r`nUPDATE_MANIFEST_URL=$updateUrl`r`nDISCORD_CLIENT_SECRET=$clientSecret`r`nACTIVITY_PORT=3000`r`nACTIVITY_PUBLIC_URL=$activityUrl`r`nCLOUDFLARE_TUNNEL_TOKEN=$tunnelToken`r`nENABLE_PRESENCE_INTENT=$presenceIntent`r`nEMERGENCY_DATA_KEY=$emergencyKey`r`n"
  $utf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
  [System.IO.File]::WriteAllText((Join-Path $script:Base 'config.env'), $content, $utf8)
  $EmergencyKeyBox.Clear()
  $EmergencyKeyState.Text = if ($emergencyKey) { '設定済み（値は非表示）' } else { '未設定' }
  $EmergencyKeyState.Foreground = if ($emergencyKey) { '#7CF3CF' } else { '#FFADBA' }
  Set-Status '設定を保存しました。' 'Green'
}
function Set-Status([string]$Text,[string]$Color='Gray') { $StatusText.Text=$Text; $StatusText.Foreground=$Color }
function Wait-ProcessWithUi($Process,[string]$Label,[int]$TimeoutSeconds=600) {
  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  while (-not $Process.HasExited) {
    if ($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds) {
      Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
      throw "$Label が $TimeoutSeconds 秒以内に完了しなかったため中止しました。"
    }
    Set-Status "$Label… $([math]::Floor($watch.Elapsed.TotalSeconds))秒" 'DarkOrange'
    $Window.Dispatcher.Invoke([Action]{},[System.Windows.Threading.DispatcherPriority]::Background)
    Start-Sleep -Milliseconds 250
  }
  return $Process.ExitCode
}
function Test-ActivityServer {
  try {
    $response = Invoke-WebRequest 'http://127.0.0.1:3000/api/config' -UseBasicParsing -TimeoutSec 2
    return $response.StatusCode -eq 200
  } catch { return $false }
}
function Test-ControlDataServer {
  try {
    $client = New-Object System.Net.Sockets.TcpClient
    $result = $client.BeginConnect('127.0.0.1', 3001, $null, $null)
    $connected = $result.AsyncWaitHandle.WaitOne(1500, $false) -and $client.Connected
    $client.Close()
    return $connected
  } catch { return $false }
}
function Refresh-Log {
  $lines = @()
  if (Test-Path $script:LogPath) { $lines += @(Get-Content $script:LogPath -Encoding UTF8 -Tail 180 -ErrorAction SilentlyContinue) }
  if (Test-Path $script:ErrorLogPath) {
    $errors = @(Get-Content $script:ErrorLogPath -Encoding UTF8 -Tail 100 -ErrorAction SilentlyContinue)
    if ($errors.Count -gt 0) { $lines += ''; $lines += '── エラー・警告ログ ──'; $lines += $errors }
  }
  if ($lines.Count -gt 0) {
    $LogBox.Text = $lines -join "`r`n"
    $LogBox.ScrollToEnd()
  }
  if ($script:BotProcess -and $script:BotProcess.HasExited) {
    Set-Status "Botは停止しています（終了コード $($script:BotProcess.ExitCode)）。" 'DarkRed'
    $script:BotProcess=$null
  }
  Refresh-QuickTunnel
  Refresh-Members
  Refresh-HistoryScan
}
function Start-HistoryScan {
  try {
    if (-not (Test-ActivityServer)) { throw '先にBotを起動してください。' }
    $guildId = $GuildBox.Text.Trim()
    if ($guildId -notmatch '^\d{17,20}$') { throw 'サーバーIDを設定して保存してください。' }
    $dataDir = Join-Path $script:Base 'data'
    New-Item $dataDir -ItemType Directory -Force | Out-Null
    $statusPath = Join-Path $dataDir 'stats-rebuild.status.json'
    if (Test-Path $statusPath) { Remove-Item $statusPath -Force }
    $request = @{ guildId=$guildId; requestedAt=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json
    $utf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
    [System.IO.File]::WriteAllText((Join-Path $dataDir 'stats-rebuild.request.json'), $request, $utf8)
    $script:LastStatsStatusStamp = $null
    $HistoryScanStatus.Text = 'Botへ集計を依頼しました。まもなく開始します…'
    Set-Status '過去統計の集計を依頼しました。通常運用はそのまま継続できます。' 'DarkOrange'
  } catch {
    Set-Status $_.Exception.Message 'DarkRed'
    [System.Windows.MessageBox]::Show($_.Exception.Message,'過去統計エラー','OK','Error') | Out-Null
  }
}
function Refresh-HistoryScan {
  $path = Join-Path $script:Base 'data\stats-rebuild.status.json'
  if (-not (Test-Path $path)) { return }
  try {
    $status = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $status.updatedAt -or $script:LastStatsStatusStamp -eq $status.updatedAt) { return }
    $script:LastStatsStatusStamp = $status.updatedAt
    if ($status.state -eq 'running') {
      $text = "集計中：#$($status.channel)　チャンネル $($status.completedChannels)/$($status.totalChannels)　読取 $([int64]$status.scannedMessages)件"
      $HistoryScanStatus.Text = $text
      Set-Status $text 'DarkOrange'
    } elseif ($status.state -eq 'completed') {
      $text = "$($status.year)年の過去統計を反映しました。読取 $([int64]$status.scannedMessages)件／対象外 $([int]$status.skippedChannels)チャンネル"
      $HistoryScanStatus.Text = $text
      Set-Status $text 'Green'
    } elseif ($status.state -eq 'failed') {
      $text = "過去統計の集計に失敗しました：$($status.message)"
      $HistoryScanStatus.Text = $text
      Set-Status $text 'DarkRed'
    }
  } catch { }
}
function Refresh-QuickTunnel {
  if (-not $script:QuickTunnelMode -or $script:QuickTunnelReadyShown) { return }
  $text = ''
  foreach ($path in @($script:QuickTunnelOut,$script:QuickTunnelError)) {
    if (Test-Path $path) { $text += "`n" + (Get-Content $path -Raw -Encoding UTF8 -ErrorAction SilentlyContinue) }
  }
  if ($text -match 'https://([a-z0-9-]+\.trycloudflare\.com)') {
    $url = $matches[0]
    $hostName = $matches[1]
    $script:QuickTunnelReadyShown = $true
    $ActivityUrlBox.Text = $url
    Save-Config
    [System.Windows.Clipboard]::SetText($hostName)
    Set-Status "無料Activity接続が準備できました：$hostName" 'Green'
    [System.Windows.MessageBox]::Show("公開先ができました。`n`n$hostName`n`nホスト名はコピー済みです。Discord Developer Portal の Activities → URL Mappings で、Prefix『/』の Targetへ貼り付けてください。`n`nこの無料URLは接続を開始し直すと変わります。",'Activity接続の準備完了','OK','Information') | Out-Null
  } elseif ($script:TunnelProcess -and $script:TunnelProcess.HasExited) {
    $script:QuickTunnelMode = $false
    Set-Status '無料Activity接続を開始できませんでした。cloudflared-error.logを確認してください。' 'DarkRed'
  }
}
function Refresh-Members {
  try {
    $live = Invoke-RestMethod 'http://127.0.0.1:3001/api/control-panel' -TimeoutSec 2
    if ($null -ne $live.members) {
      $items = @()
      foreach ($member in @($live.members)) {
        $status = switch ($member.status) { 'active' {'在籍'} 'inactive' {'休止'} 'left' {'退会'} default {$member.status} }
        $verified = if ($member.verifiedAt) { ([datetime]$member.verifiedAt).ToLocalTime().ToString('yyyy/MM/dd HH:mm') } else { '未確認' }
        $items += [PSCustomObject]@{MemberId=$member.memberId;Codename=$member.codename;DisplayName=$member.displayName;MemberStatus=$status;Verified=$verified;DiscordId=$member.userId}
      }
      $script:AllMembers = @($items | Sort-Object MemberId)
      Apply-MemberFilter
      Update-MemberSummary "Botからリアルタイム取得｜$($live.server)" $items
      Update-Dashboard $live
      Update-MinusStatus $live.minus
      return
    }
  } catch { }
  $path = Join-Path $script:Base 'data\database.json'
  if (-not (Test-Path $path)) { $MemberSummary.Text="会員データがありません｜確認先：$path"; $script:AllMembers=@(); Apply-MemberFilter; Update-Dashboard $null; Update-MinusStatus $null; return }
  try {
    $db = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json
    $guildProperty = $null
    $guildId = $GuildBox.Text.Trim()
    if ($guildId) { $guildProperty = $db.guilds.PSObject.Properties[$guildId] }
    $memberGuild = $db.guilds.PSObject.Properties | Where-Object { $_.Value.community.members.PSObject.Properties.Count -gt 0 } | Select-Object -First 1
    if (-not $guildProperty -or (-not $guildProperty.Value.community.members.PSObject.Properties.Count -and $memberGuild)) { $guildProperty = $memberGuild }
    if (-not $guildProperty) { $guildProperty = $db.guilds.PSObject.Properties | Select-Object -First 1 }
    $guildData = if ($guildProperty) { $guildProperty.Value } else { $null }
    Update-Dashboard $guildData
    Update-MinusStatus $null $guildData
    $items = @()
    if ($guildProperty -and $guildProperty.Value.community.members) {
      foreach ($property in $guildProperty.Value.community.members.PSObject.Properties) {
        $member = $property.Value
        $status = switch ($member.status) { 'active' {'在籍'} 'inactive' {'休止'} 'left' {'退会'} default {$member.status} }
        $verified = if ($member.verifiedAt) { ([datetime]$member.verifiedAt).ToLocalTime().ToString('yyyy/MM/dd HH:mm') } else { '未確認' }
        $items += [PSCustomObject]@{MemberId=$member.memberId;Codename=$member.codename;DisplayName=$(if($member.displayName){$member.displayName}else{$member.discordUsername});MemberStatus=$status;Verified=$verified;DiscordId=$member.userId}
      }
    }
    $script:AllMembers = @($items | Sort-Object MemberId)
    Apply-MemberFilter
    $sourceId = if ($guildProperty) { $guildProperty.Name } else { '不明' }
    Update-MemberSummary "保存データから取得｜サーバー $sourceId" $items
  } catch { $MemberSummary.Text="会員データを読み込めません：$($_.Exception.Message)｜$path" }
}
function Update-MinusStatus($LiveStatus,$GuildData=$null) {
  if ($LiveStatus) {
    $MinusFeature.Text = if ($LiveStatus.enabled) { '有効' } else { '未設定' }
    $EmergencyKeyState.Text = if ($LiveStatus.keyConfigured) { '設定済み（値は非表示）' } else { '未設定' }
    $MinusAgreed.Text = ([int]$LiveStatus.agreed).ToString('N0')
    $MinusContacts.Text = ([int]$LiveStatus.contacts).ToString('N0')
    $MinusReconsent.Text = ([int]$LiveStatus.reconsent).ToString('N0')
  } else {
    $minus = $GuildData.minus
    $consents = if ($minus.consents) { @($minus.consents.PSObject.Properties | ForEach-Object {$_.Value}) } else { @() }
    $MinusFeature.Text = if ($minus.config) { '有効' } else { '未設定' }
    $MinusAgreed.Text = @($consents | Where-Object {$_.status -eq 'agreed'}).Count.ToString('N0')
    $MinusReconsent.Text = @($consents | Where-Object {$_.status -eq 'reconsent_required'}).Count.ToString('N0')
    $contactPath = Join-Path $script:Base 'data\emergency-contacts.json'
    try { $contactDb = Get-Content $contactPath -Raw -Encoding UTF8 | ConvertFrom-Json; $gid=$GuildBox.Text.Trim(); $MinusContacts.Text=@($contactDb.guilds.$gid.PSObject.Properties).Count.ToString('N0') } catch { $MinusContacts.Text='0' }
    $envNow=Read-EnvFile; $EmergencyKeyState.Text=if($envNow.EMERGENCY_DATA_KEY){'設定済み（値は非表示）'}else{'未設定'}
  }
  $EmergencyKeyState.Foreground = if ($EmergencyKeyState.Text -like '設定済み*') { '#7CF3CF' } else { '#FFADBA' }
}
function Apply-MemberFilter {
  if (-not $MemberGrid) { return }
  $query = if ($MemberSearchBox) { $MemberSearchBox.Text.Trim() } else { '' }
  $state = if ($MemberStateFilter -and $MemberStateFilter.SelectedItem) { [string]$MemberStateFilter.SelectedItem.Content } else { 'すべて' }
  $filtered = @($script:AllMembers | Where-Object {
    ($state -eq 'すべて' -or $_.MemberStatus -eq $state) -and
    ([string]::IsNullOrWhiteSpace($query) -or
      ([string]$_.MemberId).IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or
      ([string]$_.Codename).IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or
      ([string]$_.DisplayName).IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or
      ([string]$_.DiscordId).IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -ge 0)
  })
  $MemberGrid.ItemsSource = $filtered
  if ($MemberVisibleCount) { $MemberVisibleCount.Text = "表示 $($filtered.Count)名" }
}
function Update-MemberSummary([string]$Source,$Items) {
  $all = @($Items)
  $active = @($all | Where-Object {$_.MemberStatus -eq '在籍'}).Count
  $unverified = @($all | Where-Object {$_.Verified -eq '未確認'}).Count
  $MemberSummary.Text = "$Source｜最終更新 $(Get-Date -Format 'HH:mm:ss')"
  $MemberTotal.Text = $all.Count.ToString('N0')
  $MemberActive.Text = $active.ToString('N0')
  $MemberUnverified.Text = $unverified.ToString('N0')
}
function Update-Dashboard($GuildData) {
  $TodayMessages.Text = '0'; $MonthMessages.Text = '0'; $YearMessages.Text = '0'; $OnlineMembers.Text = '—'; $OfflineMembers.Text = '—'
  $running = Test-ActivityServer
  $BotHealth.Text = if ($running) { '稼働中' } else { '停止中' }
  $BotHealth.Foreground = if ($running) { '#15966A' } else { '#C74759' }
  if (-not $GuildData) { $PresenceHint.Text = '統計データはまだありません。'; return }
  $now = Get-Date
  $todayKey = $now.ToString('yyyy-MM-dd')
  $monthKey = $now.ToString('yyyy-MM')
  $yearKey = $now.ToString('yyyy')
  $days = $GuildData.analytics.messages.byDay
  if ($days) {
    $today = 0; $month = 0; $year = 0
    foreach ($property in $days.PSObject.Properties) {
      $count = [int64]$property.Value
      if ($property.Name -eq $todayKey) { $today += $count }
      if ($property.Name.StartsWith($monthKey)) { $month += $count }
      if ($property.Name.StartsWith($yearKey)) { $year += $count }
    }
    $TodayMessages.Text = $today.ToString('N0'); $MonthMessages.Text = $month.ToString('N0'); $YearMessages.Text = $year.ToString('N0')
  }
  $presence = $GuildData.analytics.presence
  if ($presence.enabled) {
    $OnlineMembers.Text = ([int]$presence.online).ToString('N0')
    $OfflineMembers.Text = ([int]$presence.offline).ToString('N0')
    $PresenceHint.Text = "Discord接続状況を自動更新中　／　対象 $($presence.total)名"
  } else {
    $PresenceHint.Text = 'オンライン統計を使うには、Discord Developer PortalのServer Members IntentとPresence Intentを有効にして、設定欄にもチェックを入れてください。'
  }
}
function Ensure-Node {
  if (Get-Command node.exe -ErrorAction SilentlyContinue) { return $true }
  Set-Status 'Node.jsを自動インストールしています…' 'DarkOrange'
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if ($winget) {
    $p=Start-Process winget.exe -ArgumentList 'install --id OpenJS.NodeJS.LTS --exact --silent --accept-package-agreements --accept-source-agreements' -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Node.jsの導入に失敗しました（winget: $($p.ExitCode)）。" }
  } else {
    $index=Invoke-RestMethod 'https://nodejs.org/dist/index.json'
    $release=$index | Where-Object {$_.lts -and $_.files -contains 'win-x64-msi'} | Select-Object -First 1
    if (-not $release) { throw 'Node.js LTSの配布情報を取得できません。' }
    $msi=Join-Path $env:TEMP "node-$($release.version)-x64.msi"
    Invoke-WebRequest "https://nodejs.org/dist/$($release.version)/node-$($release.version)-x64.msi" -OutFile $msi
    $p=Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Node.jsの導入に失敗しました（MSI: $($p.ExitCode)）。" }
  }
  $env:Path += ';' + ${env:ProgramFiles} + '\nodejs'
  return [bool](Get-Command node.exe -ErrorAction SilentlyContinue)
}
function Ensure-Packages {
  if ((Test-Path (Join-Path $script:Base 'node_modules\discord.js')) -and (Test-Path (Join-Path $script:Base 'node_modules\pdfkit'))) { return }
  Set-Status '必要なプログラムをインストールしています…' 'DarkOrange'
  $npm=(Get-Command npm.cmd -ErrorAction Stop).Source
  $p=Start-Process $npm -ArgumentList 'ci --omit=dev --loglevel=error --no-audit --no-fund --prefer-offline' -WorkingDirectory $script:Base -PassThru -WindowStyle Hidden -RedirectStandardOutput $script:LogPath -RedirectStandardError (Join-Path $script:Base 'startup-error.log')
  $exitCode = Wait-ProcessWithUi $p 'Bot用パッケージをインストールしています' 600
  if ($exitCode -ne 0) { throw '必要なファイルのインストールに失敗しました。startup-error.logを確認してください。' }
  Set-Status 'Bot用パッケージのインストールが完了しました。' 'Green'
}
function Test-CloudflaredBinary([string]$Path) {
  if (-not (Test-Path $Path -PathType Leaf)) { return $false }
  try {
    $signature = Get-AuthenticodeSignature $Path
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notlike '*Cloudflare*') { return $false }
    $test = Start-Process $Path -ArgumentList '--version' -Wait -PassThru -WindowStyle Hidden
    return $test.ExitCode -eq 0
  } catch { return $false }
}
function Ensure-Cloudflared {
  $command = Get-Command cloudflared.exe -ErrorAction SilentlyContinue
  if ($command -and (Test-CloudflaredBinary $command.Source)) { return $command.Source }
  $local = Join-Path $script:Base 'tools\cloudflared.exe'
  if (Test-CloudflaredBinary $local) { return $local }
  if (Test-Path $local) { Remove-Item $local -Force }
  Set-Status 'Activity用のCloudflare Tunnelを自動インストールしています…' 'DarkOrange'
  New-Item (Split-Path $local -Parent) -ItemType Directory -Force | Out-Null
  $architecture = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
  $asset = switch ($architecture) { 'Arm64' {'cloudflared-windows-arm64.exe'} 'X86' {'cloudflared-windows-386.exe'} default {'cloudflared-windows-amd64.exe'} }
  $download = Join-Path (Split-Path $local -Parent) 'cloudflared.download.exe'
  if (Test-Path $download) { Remove-Item $download -Force }
  try {
    Invoke-WebRequest "https://github.com/cloudflare/cloudflared/releases/latest/download/$asset" -OutFile $download -UseBasicParsing -TimeoutSec 180
    if (-not (Test-CloudflaredBinary $download)) { throw "このPC（$architecture）で実行できるCloudflare公式ファイルではありません。" }
    Move-Item $download $local -Force
  } finally {
    if (Test-Path $download) { Remove-Item $download -Force }
  }
  return $local
}
function Start-ActivityTunnel {
  $token = $TunnelTokenBox.Password.Trim()
  if (-not $token) { return }
  if ($token -notmatch '^[A-Za-z0-9._=-]+$') { throw 'Cloudflare Tunnelトークンの形式が正しくありません。' }
  if ($script:TunnelProcess -and -not $script:TunnelProcess.HasExited) { return }
  $cloudflared = Ensure-Cloudflared
  $info = New-Object System.Diagnostics.ProcessStartInfo
  $info.FileName = $cloudflared
  $info.Arguments = "tunnel run --token $token"
  $info.WorkingDirectory = $script:Base
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $script:TunnelProcess = [System.Diagnostics.Process]::Start($info)
}
function Start-QuickTunnel {
  try {
    if (-not (Test-ActivityServer)) {
      Start-Bot
      for ($attempt = 0; $attempt -lt 30 -and -not (Test-ActivityServer); $attempt++) { Start-Sleep -Milliseconds 500 }
      if (-not (Test-ActivityServer)) { throw 'BotのActivityサーバーを確認できません。稼働ログを確認してください。' }
    }
    if ($script:TunnelProcess -and -not $script:TunnelProcess.HasExited) {
      Stop-Process -Id $script:TunnelProcess.Id
      $script:TunnelProcess.WaitForExit()
    }
    $cloudflared = Ensure-Cloudflared
    foreach ($path in @($script:QuickTunnelOut,$script:QuickTunnelError)) {
      if (Test-Path $path) { Remove-Item $path -Force }
    }
    $port = 3000
    $script:QuickTunnelMode = $true
    $script:QuickTunnelReadyShown = $false
    $script:TunnelProcess = Start-Process $cloudflared -ArgumentList "tunnel --url http://127.0.0.1:$port --no-autoupdate" -WorkingDirectory $script:Base -PassThru -WindowStyle Hidden -RedirectStandardOutput $script:QuickTunnelOut -RedirectStandardError $script:QuickTunnelError
    Set-Status '無料Activity接続を準備しています…（通常10～30秒）' 'DarkOrange'
  } catch {
    $script:QuickTunnelMode = $false
    Set-Status $_.Exception.Message 'DarkRed'
    [System.Windows.MessageBox]::Show($_.Exception.Message,'Activity接続エラー','OK','Error') | Out-Null
  }
}
function Start-AllServers {
  $StartButton.IsEnabled = $false
  $QuickTunnelButton.IsEnabled = $false
  try {
    Save-Config
    Set-Status '一括起動 1/5：Node.jsと必要ファイルを確認しています…' 'DarkOrange'
    if (-not (Ensure-Node)) { throw 'Node.jsを確認できません。Windowsを再起動してからお試しください。' }
    Ensure-Packages
    Set-Status '一括起動 2/5：公開接続プログラムを確認しています…' 'DarkOrange'
    $null = Ensure-Cloudflared
    Set-Status '一括起動 3/5：BotとActivityサーバーを起動しています…' 'DarkOrange'
    Start-Bot
    for ($attempt = 0; $attempt -lt 40 -and -not (Test-ActivityServer); $attempt++) {
      $Window.Dispatcher.Invoke([Action]{},[System.Windows.Threading.DispatcherPriority]::Background)
      Start-Sleep -Milliseconds 500
    }
    if (-not (Test-ActivityServer)) { throw 'Activityサーバーを起動できませんでした。画面下部の稼働ログを確認してください。' }
    if (-not (Test-ControlDataServer)) { throw '管理画面データサーバーを起動できませんでした。画面下部の稼働ログを確認してください。' }
    Set-Status '一括起動 4/5：Activity公開リンクを作成しています…' 'DarkOrange'
    Start-QuickTunnel
    Set-Status '一括起動 5/5：公開URLの発行を待っています…（通常10～30秒）' 'DarkOrange'
  } catch {
    Set-Status $_.Exception.Message 'DarkRed'
    [System.Windows.MessageBox]::Show($_.Exception.Message,'サーバー起動エラー','OK','Error') | Out-Null
  } finally {
    $StartButton.IsEnabled = $true
    $QuickTunnelButton.IsEnabled = $true
  }
}
function Start-Bot {
  try {
    Save-Config
    if (-not $TokenBox.Password.Trim() -or $TokenBox.Password -like '*ここにBotトークン*') { throw 'Botトークンを入力してください。' }
    if (Test-ActivityServer) { Set-Status 'Botは既に起動しています。' 'Green'; return }
    if (-not (Ensure-Node)) { throw 'Node.jsを確認できません。Windowsを再起動してからお試しください。' }
    Ensure-Packages
    Start-ActivityTunnel
    if ($script:BotProcess -and -not $script:BotProcess.HasExited) { Set-Status 'Botは既に起動しています。' 'Green'; return }
    $utf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
    [System.IO.File]::WriteAllText($script:LogPath, "[$(Get-Date)] Botを起動します。`r`n", $utf8)
    $node=(Get-Command node.exe -ErrorAction Stop).Source
    $script:BotProcess=Start-Process $node -ArgumentList 'bot.js' -WorkingDirectory $script:Base -PassThru -WindowStyle Hidden -RedirectStandardOutput $script:LogPath -RedirectStandardError (Join-Path $script:Base 'startup-error.log')
    Set-Status "Botを起動しました（PID $($script:BotProcess.Id)）。" 'Green'
  } catch { Set-Status $_.Exception.Message 'DarkRed'; [System.Windows.MessageBox]::Show($_.Exception.Message,'起動エラー','OK','Error') | Out-Null }
}
function Stop-Bot {
  $stopped = $false
  if ($script:BotProcess -and -not $script:BotProcess.HasExited) {
    Stop-Process -Id $script:BotProcess.Id -Force -ErrorAction SilentlyContinue
    $script:BotProcess.WaitForExit()
    $stopped = $true
  }
  $script:BotProcess=$null
  # 管理画面を開き直した場合も、Botが使用中のローカルポートからPIDを特定して停止する。
  foreach ($port in @(3000,3001)) {
    foreach ($connection in @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)) {
      try {
        $process = Get-Process -Id $connection.OwningProcess -ErrorAction Stop
        if ($process.ProcessName -in @('node','node.exe')) {
          Stop-Process -Id $process.Id -Force -ErrorAction Stop
          $stopped = $true
        }
      } catch { }
    }
  }
  if ($script:TunnelProcess -and -not $script:TunnelProcess.HasExited) { Stop-Process -Id $script:TunnelProcess.Id; $script:TunnelProcess=$null }
  $script:QuickTunnelMode = $false
  $script:QuickTunnelReadyShown = $false
  if ($stopped) { Set-Status '稼働中のBotを停止しました。再起動できます。' 'DarkRed' }
  else { Set-Status 'Botは停止しています。' 'DarkRed' }
}
function Check-Update {
  try {
    Save-Config
    $url=$UpdateBox.Text.Trim()
    if (-not $url.StartsWith('https://')) { throw '更新マニフェストにはHTTPSのURLを設定してください。' }
    Set-Status '更新情報を確認しています…' 'DarkOrange'
    $m=Invoke-RestMethod $url
    if (-not $m.version -or -not $m.url -or $m.sha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw '更新情報のversion、url、sha256が正しくありません。' }
    if ([version]$m.version -le [version]$script:Version) { Set-Status "最新版です（v$script:Version）。" 'Green'; return }
    $answer=[System.Windows.MessageBox]::Show("v$($m.version)があります。設定とデータを残して更新しますか？",'更新','YesNo','Question')
    if ($answer -ne 'Yes') { Set-Status '更新をキャンセルしました。'; return }
    $zip=Join-Path $env:TEMP "JohotaiBot-$($m.version).zip"
    Invoke-WebRequest ([string]$m.url) -OutFile $zip
    $actual=(Get-FileHash $zip -Algorithm SHA256).Hash
    if ($actual -ne ([string]$m.sha256).ToUpperInvariant()) { Remove-Item $zip -Force; throw '更新ファイルのSHA256が一致しないため中止しました。' }
    Stop-Bot
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $script:Base 'Update-Bot.ps1')`" -ZipPath `"$zip`" -InstallDir `"$script:Base`" -WaitPid $PID" -WindowStyle Hidden
    $Window.Close()
  } catch { Set-Status $_.Exception.Message 'DarkRed'; [System.Windows.MessageBox]::Show($_.Exception.Message,'更新エラー','OK','Error') | Out-Null }
}

Restore-LegacyDatabase

[xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="論談会・情報保安対策委員会｜統合管理センター" Height="850" Width="1220" MinHeight="590" MinWidth="780" WindowStartupLocation="CenterScreen" Background="#050D18" ResizeMode="CanResizeWithGrip" TextOptions.TextFormattingMode="Display">
 <Window.Resources>
  <Style TargetType="TextBlock"><Setter Property="FontFamily" Value="Yu Gothic UI"/></Style>
  <Style TargetType="Button"><Setter Property="FontFamily" Value="Yu Gothic UI"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Padding" Value="17,10"/><Setter Property="Margin" Value="0,0,9,0"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Background" Value="#111E35"/><Setter Property="Foreground" Value="#F5F1E8"/><Setter Property="BorderBrush" Value="#806A36"/><Setter Property="BorderThickness" Value="1"/></Style>
  <Style x:Key="PrimaryButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Background" Value="#C99A32"/><Setter Property="Foreground" Value="#07101D"/><Setter Property="BorderBrush" Value="#F1CC70"/></Style>
  <Style x:Key="PurpleButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Background" Value="#5865F2"/><Setter Property="Foreground" Value="White"/><Setter Property="BorderBrush" Value="#7C86FF"/></Style>
  <Style x:Key="DangerButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Background" Value="#3A202A"/><Setter Property="Foreground" Value="#FF9BAD"/><Setter Property="BorderBrush" Value="#713143"/></Style>
  <Style TargetType="TabItem"><Setter Property="FontFamily" Value="Yu Gothic UI"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="FontSize" Value="14"/><Setter Property="Foreground" Value="#9AB5BE"/><Setter Property="Background" Value="#102630"/><Setter Property="BorderBrush" Value="#214653"/><Setter Property="Padding" Value="22,12"/><Setter Property="Margin" Value="0,0,5,0"/><Style.Triggers><Trigger Property="IsSelected" Value="True"><Setter Property="Foreground" Value="#04161C"/><Setter Property="Background" Value="#35D9EC"/><Setter Property="BorderBrush" Value="#62EDFA"/></Trigger></Style.Triggers></Style>
  <Style TargetType="TextBox"><Setter Property="FontFamily" Value="Yu Gothic UI"/><Setter Property="Background" Value="#0D2029"/><Setter Property="Foreground" Value="#E9F7FA"/><Setter Property="BorderBrush" Value="#264754"/><Setter Property="CaretBrush" Value="#42DCEF"/><Setter Property="Padding" Value="9"/></Style>
  <Style TargetType="PasswordBox"><Setter Property="FontFamily" Value="Yu Gothic UI"/><Setter Property="Background" Value="#0D2029"/><Setter Property="Foreground" Value="#E9F7FA"/><Setter Property="BorderBrush" Value="#264754"/><Setter Property="Padding" Value="9"/></Style>
 </Window.Resources>
 <Grid>
  <Grid.RowDefinitions><RowDefinition Height="104"/><RowDefinition Height="62"/><RowDefinition Height="*"/><RowDefinition Height="40"/></Grid.RowDefinitions>
  <Border Grid.Row="0" Background="#081426" BorderBrush="#B78B32" BorderThickness="0,0,0,2" Padding="22,8">
   <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
    <StackPanel Orientation="Horizontal" VerticalAlignment="Center"><Border Width="76" Height="76" CornerRadius="10" BorderBrush="#C99A32" BorderThickness="1" Background="#FFFDF5" Padding="5"><Image Name="RondankaiLogo" Stretch="Uniform" SnapsToDevicePixels="True"/></Border><Border Width="1" Height="55" Background="#745F30" Margin="12,0"/><Border Width="76" Height="76" CornerRadius="10" BorderBrush="#20C6DA" BorderThickness="1" Background="White" Padding="4"><Image Name="JohotaiLogo" Stretch="Uniform" SnapsToDevicePixels="True"/></Border></StackPanel>
    <StackPanel Grid.Column="1" Margin="18,0,0,0" VerticalAlignment="Center"><TextBlock Text="RONDANKAI × INFORMATION SECURITY COMMITTEE" FontSize="10" Foreground="#DDB758" FontWeight="SemiBold"/><TextBlock Text="論談会　統合管理センター" FontSize="25" FontWeight="Bold" Foreground="#FFF9E9"/><TextBlock Text="情報保安対策委員会 Security Operations Center" FontSize="11" Foreground="#55D9E9" Margin="0,2,0,0"/></StackPanel>
    <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center"><Border Background="#0D292F" BorderBrush="#20AFA5" BorderThickness="1" CornerRadius="18" Padding="15,7"><StackPanel Orientation="Horizontal"><Ellipse Width="9" Height="9" Fill="#2DE2A7" Margin="0,0,8,0"/><TextBlock Name="BotHealth" Text="確認中" FontWeight="Bold" Foreground="#A4F5D9"/></StackPanel></Border><TextBlock Text="v4.1.2" Foreground="#BFA25D" VerticalAlignment="Center" Margin="14,0,0,0"/></StackPanel>
   </Grid>
  </Border>
  <Border Grid.Row="1" Background="#0A1728" BorderBrush="#4D432B" BorderThickness="0,0,0,1" Padding="24,10">
   <DockPanel><StackPanel Orientation="Horizontal"><Button Name="StartButton" Content="▶  全サーバー＋公開リンクを起動" Style="{StaticResource PrimaryButton}" ToolTip="必要プログラムの確認からBot・Activity・管理データサーバー・公開リンク発行まで自動実行"/><Button Name="StopButton" Content="■  すべて停止" Style="{StaticResource DangerButton}"/><Button Name="QuickTunnelButton" Content="◆  公開リンクだけ再作成" Style="{StaticResource PurpleButton}" ToolTip="Activityサーバーはそのままで無料公開URLだけを作り直します"/><Button Name="UpdateButton" Content="↻  更新を確認"/></StackPanel><TextBlock DockPanel.Dock="Right" Text="LIVE CONTROL" Foreground="#315865" FontSize="11" FontWeight="Bold" VerticalAlignment="Center" HorizontalAlignment="Right"/></DockPanel>
  </Border>
  <Border Grid.Row="2" Margin="18" Background="#091524" BorderBrush="#6E592C" BorderThickness="1" CornerRadius="12" ClipToBounds="True">
   <ScrollViewer HorizontalScrollBarVisibility="Auto" VerticalScrollBarVisibility="Auto">
    <Grid Name="ScaledContent" MinWidth="700" MinHeight="430">
     <Grid.LayoutTransform><ScaleTransform ScaleX="{Binding ElementName=ZoomSlider,Path=Value}" ScaleY="{Binding ElementName=ZoomSlider,Path=Value}"/></Grid.LayoutTransform>
     <TabControl Background="Transparent" BorderThickness="0" Margin="8">
      <TabItem Header="概要">
       <ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel Margin="14">
        <Grid Margin="0,4,0,16"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="運用状況" FontSize="25" FontWeight="Bold" Foreground="#F1FAFC"/><TextBlock Text="日本時間・約2秒間隔でリアルタイム更新" Foreground="#6E929E" Margin="0,4,0,0"/></StackPanel><TextBlock Grid.Column="1" Text="LIVE TELEMETRY" Foreground="#2DD7EB" FontWeight="Bold" VerticalAlignment="Bottom"/></Grid>
        <UniformGrid Columns="3" Margin="-6,0,-6,12">
         <Border Background="#0C2631" BorderBrush="#155369" BorderThickness="1" CornerRadius="10" Padding="18" Margin="6"><StackPanel><TextBlock Text="TODAY / 今日" Foreground="#57D9E8" FontWeight="Bold"/><TextBlock Name="TodayMessages" Text="0" FontSize="38" FontWeight="Bold" Foreground="White" Margin="0,5,0,0"/><TextBlock Text="MESSAGES" FontSize="10" Foreground="#4F7480"/></StackPanel></Border>
         <Border Background="#0C2631" BorderBrush="#155369" BorderThickness="1" CornerRadius="10" Padding="18" Margin="6"><StackPanel><TextBlock Text="MONTH / 今月" Foreground="#57D9E8" FontWeight="Bold"/><TextBlock Name="MonthMessages" Text="0" FontSize="38" FontWeight="Bold" Foreground="White" Margin="0,5,0,0"/><TextBlock Text="MESSAGES" FontSize="10" Foreground="#4F7480"/></StackPanel></Border>
         <Border Background="#0C2631" BorderBrush="#155369" BorderThickness="1" CornerRadius="10" Padding="18" Margin="6"><StackPanel><TextBlock Text="YEAR / 今年" Foreground="#57D9E8" FontWeight="Bold"/><TextBlock Name="YearMessages" Text="0" FontSize="38" FontWeight="Bold" Foreground="White" Margin="0,5,0,0"/><TextBlock Text="MESSAGES" FontSize="10" Foreground="#4F7480"/></StackPanel></Border>
        </UniformGrid>
        <Grid Margin="-6,0,-6,12"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
         <Border Background="#0D2827" BorderBrush="#176354" BorderThickness="1" CornerRadius="10" Padding="18" Margin="6"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="ONLINE MEMBERS" Foreground="#55DEB5" FontWeight="Bold"/><TextBlock Text="Discord接続中" Foreground="#628D82" Margin="0,4,0,0"/></StackPanel><TextBlock Name="OnlineMembers" Grid.Column="1" Text="—" FontSize="36" FontWeight="Bold" Foreground="#7CF3CF" VerticalAlignment="Center"/></Grid></Border>
         <Border Grid.Column="1" Background="#182126" BorderBrush="#35444B" BorderThickness="1" CornerRadius="10" Padding="18" Margin="6"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="OFFLINE MEMBERS" Foreground="#9AABB1" FontWeight="Bold"/><TextBlock Text="Discord未接続" Foreground="#65777D" Margin="0,4,0,0"/></StackPanel><TextBlock Name="OfflineMembers" Grid.Column="1" Text="—" FontSize="36" FontWeight="Bold" Foreground="#C1CDD1" VerticalAlignment="Center"/></Grid></Border>
        </Grid>
        <TextBlock Name="PresenceHint" Text="接続状況を確認しています…" TextWrapping="Wrap" Foreground="#6E929E" Margin="4,0,4,12"/>
        <Border Background="#0D202A" BorderBrush="#245263" BorderThickness="1" CornerRadius="10" Padding="16" Margin="0,0,0,6"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="HISTORICAL MESSAGE INDEX" Foreground="#39D9ED" FontWeight="Bold"/><TextBlock Name="HistoryScanStatus" Text="今年1月1日以降の投稿を読み取り、統計へ反映できます。" TextWrapping="Wrap" Foreground="#89A7B0" Margin="0,5,12,0"/></StackPanel><Button Name="HistoryScanButton" Grid.Column="1" Content="過去統計を集計" Style="{StaticResource PrimaryButton}" Margin="8,0,0,0" VerticalAlignment="Center" ToolTip="今年1月1日以降の投稿を読み直して統計へ反映"/></Grid></Border>
       </StackPanel></ScrollViewer>
      </TabItem>
      <TabItem Header="会員モニター">
       <Grid Margin="14"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
        <Grid Margin="0,2,0,12"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="会員ディレクトリ" FontSize="25" FontWeight="Bold" Foreground="#F1FAFC"/><TextBlock Name="MemberSummary" Text="会員データを読み込んでいます…" Foreground="#79A3AF" Margin="0,4,0,0"/></StackPanel><TextBlock Name="MemberVisibleCount" Grid.Column="1" Text="表示 0名" Foreground="#45DCEC" FontSize="15" FontWeight="Bold" VerticalAlignment="Bottom"/></Grid>
        <UniformGrid Grid.Row="1" Columns="3" Margin="-5,0,-5,12"><Border Background="#0C2631" BorderBrush="#155369" BorderThickness="1" CornerRadius="9" Padding="15" Margin="5"><StackPanel><TextBlock Text="登録会員" Foreground="#70AAB8"/><TextBlock Name="MemberTotal" Text="0" FontSize="28" FontWeight="Bold" Foreground="White"/></StackPanel></Border><Border Background="#0D2827" BorderBrush="#176354" BorderThickness="1" CornerRadius="9" Padding="15" Margin="5"><StackPanel><TextBlock Text="在籍" Foreground="#62CBB0"/><TextBlock Name="MemberActive" Text="0" FontSize="28" FontWeight="Bold" Foreground="#7CF3CF"/></StackPanel></Border><Border Background="#2A2022" BorderBrush="#6B4148" BorderThickness="1" CornerRadius="9" Padding="15" Margin="5"><StackPanel><TextBlock Text="本人確認待ち" Foreground="#D6909C"/><TextBlock Name="MemberUnverified" Text="0" FontSize="28" FontWeight="Bold" Foreground="#FFADBA"/></StackPanel></Border></UniformGrid>
        <Grid Grid.Row="2" Margin="0,0,0,10"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="150"/></Grid.ColumnDefinitions><TextBox Name="MemberSearchBox" FontSize="14" Padding="12,10" ToolTip="会員番号・コードネーム・Discord表示名・Discord IDで検索"/><ComboBox Name="MemberStateFilter" Grid.Column="1" SelectedIndex="0" Margin="10,0,0,0" Padding="8" Background="#12303B" Foreground="#E9F7FA" BorderBrush="#2C6474"><ComboBox.Resources><SolidColorBrush x:Key="{x:Static SystemColors.WindowBrushKey}" Color="#12303B"/><SolidColorBrush x:Key="{x:Static SystemColors.ControlBrushKey}" Color="#12303B"/><SolidColorBrush x:Key="{x:Static SystemColors.ControlTextBrushKey}" Color="#E9F7FA"/></ComboBox.Resources><ComboBoxItem Content="すべて" Foreground="#102028"/><ComboBoxItem Content="在籍" Foreground="#102028"/><ComboBoxItem Content="休止" Foreground="#102028"/><ComboBoxItem Content="退会" Foreground="#102028"/></ComboBox></Grid>
        <Border Grid.Row="3" Background="#081A22" BorderBrush="#234653" BorderThickness="1" CornerRadius="9" Padding="1"><DataGrid Name="MemberGrid" MinWidth="980" IsReadOnly="True" AutoGenerateColumns="False" CanUserAddRows="False" CanUserResizeColumns="True" HeadersVisibility="Column" RowHeight="46" ColumnHeaderHeight="46" FontSize="14" Background="#081A22" Foreground="#E7F5F8" RowBackground="#0B2029" AlternatingRowBackground="#102B35" HorizontalGridLinesBrush="#1C3B47" VerticalGridLinesBrush="#1C3B47" BorderThickness="0" GridLinesVisibility="All" SelectionMode="Single" SelectionUnit="FullRow" HorizontalScrollBarVisibility="Auto" VerticalScrollBarVisibility="Auto"><DataGrid.Resources><Style TargetType="DataGridCell"><Setter Property="Padding" Value="10,8"/><Setter Property="Foreground" Value="#E7F5F8"/><Setter Property="BorderBrush" Value="#1C3B47"/><Setter Property="BorderThickness" Value="0,0,1,1"/><Setter Property="VerticalContentAlignment" Value="Center"/></Style><Style TargetType="DataGridColumnHeader"><Setter Property="Background" Value="#12303B"/><Setter Property="Foreground" Value="#8FE7F1"/><Setter Property="FontWeight" Value="Bold"/><Setter Property="FontSize" Value="14"/><Setter Property="Padding" Value="10,8"/><Setter Property="BorderBrush" Value="#2B5968"/><Setter Property="BorderThickness" Value="0,0,1,1"/><Setter Property="VerticalContentAlignment" Value="Center"/></Style></DataGrid.Resources><DataGrid.Columns><DataGridTextColumn Header="会員番号" Binding="{Binding MemberId}" Width="125"/><DataGridTextColumn Header="コードネーム" Binding="{Binding Codename}" Width="180"/><DataGridTextColumn Header="Discord表示名" Binding="{Binding DisplayName}" Width="200"/><DataGridTextColumn Header="在籍状態" Binding="{Binding MemberStatus}" Width="105"/><DataGridTextColumn Header="本人確認日時" Binding="{Binding Verified}" Width="180"/><DataGridTextColumn Header="Discord ID" Binding="{Binding DiscordId}" Width="190"/></DataGrid.Columns></DataGrid></Border>
       </Grid>
      </TabItem>
      <TabItem Header="マイナス管理">
       <ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel Margin="18"><TextBlock Text="マイナスチャンネル管理" FontSize="25" FontWeight="Bold" Foreground="#F1FAFC"/><TextBlock Text="同意状況と暗号化緊急連絡先の登録状況のみ表示します。連絡先本文は表示しません。" Foreground="#71939E" Margin="0,5,0,16"/>
        <UniformGrid Columns="3" Margin="-5,0,-5,12"><Border Background="#0C2631" BorderBrush="#155369" BorderThickness="1" CornerRadius="9" Padding="16" Margin="5"><StackPanel><TextBlock Text="機能状態" Foreground="#70AAB8"/><TextBlock Name="MinusFeature" Text="確認中" FontSize="25" FontWeight="Bold" Foreground="#8FE7F1"/></StackPanel></Border><Border Background="#0D2827" BorderBrush="#176354" BorderThickness="1" CornerRadius="9" Padding="16" Margin="5"><StackPanel><TextBlock Text="規程同意済み" Foreground="#62CBB0"/><TextBlock Name="MinusAgreed" Text="0" FontSize="28" FontWeight="Bold" Foreground="#7CF3CF"/></StackPanel></Border><Border Background="#2A2022" BorderBrush="#6B4148" BorderThickness="1" CornerRadius="9" Padding="16" Margin="5"><StackPanel><TextBlock Text="再同意待ち" Foreground="#D6909C"/><TextBlock Name="MinusReconsent" Text="0" FontSize="28" FontWeight="Bold" Foreground="#FFADBA"/></StackPanel></Border></UniformGrid>
        <Grid Margin="-5,0,-5,12"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border Background="#0C2631" BorderBrush="#155369" BorderThickness="1" CornerRadius="9" Padding="16" Margin="5"><StackPanel><TextBlock Text="緊急連絡先登録数" Foreground="#70AAB8"/><TextBlock Name="MinusContacts" Text="0" FontSize="28" FontWeight="Bold" Foreground="White"/></StackPanel></Border><Border Grid.Column="1" Background="#0D202A" BorderBrush="#234653" BorderThickness="1" CornerRadius="9" Padding="16" Margin="5"><StackPanel><TextBlock Text="暗号鍵 EMERGENCY_DATA_KEY" Foreground="#70AAB8"/><TextBlock Name="EmergencyKeyState" Text="未設定" FontSize="20" FontWeight="Bold" Foreground="#FFADBA" Margin="0,5,0,0"/><TextBlock Text="鍵の値は安全のため管理画面・ログへ表示しません。" Foreground="#71939E" Margin="0,5,0,0"/></StackPanel></Border></Grid>
        <Border Background="#0D202A" BorderBrush="#234653" BorderThickness="1" CornerRadius="10" Padding="18"><StackPanel><TextBlock Text="暗号鍵を設定・変更" FontWeight="Bold" Foreground="#BFEAF1"/><TextBlock Text="32バイト以上のランダム値をBase64形式で入力してください。空欄で保存した場合、現在の鍵を保持します。鍵を変更すると既存データを復号できなくなります。" TextWrapping="Wrap" Foreground="#71939E" Margin="0,5,0,10"/><PasswordBox Name="EmergencyKeyBox" Padding="11"/><TextBlock Text="生成例（PowerShell）：[Convert]::ToBase64String([byte[]](1..32 | ForEach-Object { Get-Random -Maximum 256 }))" TextWrapping="Wrap" Foreground="#5F818D" Margin="0,9,0,0"/><Button Name="KeySaveButton" Content="暗号鍵を保存" Style="{StaticResource PrimaryButton}" HorizontalAlignment="Left" Margin="0,14,0,0"/></StackPanel></Border>
       </StackPanel></ScrollViewer>
      </TabItem>
      <TabItem Header="接続・設定">
       <ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel Margin="18" MaxWidth="880" HorizontalAlignment="Left"><TextBlock Text="SYSTEM CONFIGURATION" FontSize="23" FontWeight="Bold" Foreground="#F1FAFC"/><TextBlock Text="Bot・Discord Activity・自動更新の接続情報" Foreground="#71939E" Margin="0,4,0,16"/><Border Background="#0D202A" BorderBrush="#234653" BorderThickness="1" CornerRadius="10" Padding="18"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="210"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
        <TextBlock Text="Botトークン" Foreground="#A7C1C8" VerticalAlignment="Center"/><PasswordBox Name="TokenBox" Grid.Column="1" Margin="6"/>
        <TextBlock Grid.Row="1" Text="サーバーID" Foreground="#A7C1C8" VerticalAlignment="Center"/><TextBox Name="GuildBox" Grid.Row="1" Grid.Column="1" Margin="6"/>
        <TextBlock Grid.Row="2" Text="受付番号の接頭辞" Foreground="#A7C1C8" VerticalAlignment="Center"/><TextBox Name="PrefixBox" Grid.Row="2" Grid.Column="1" Margin="6" Text="JHT"/>
        <TextBlock Grid.Row="3" Text="テーマ色" Foreground="#A7C1C8" VerticalAlignment="Center"/><TextBox Name="ColorBox" Grid.Row="3" Grid.Column="1" Margin="6" Text="00BCD4"/>
        <TextBlock Grid.Row="4" Text="更新情報URL" Foreground="#A7C1C8" VerticalAlignment="Center"/><TextBox Name="UpdateBox" Grid.Row="4" Grid.Column="1" Margin="6"/>
        <TextBlock Grid.Row="5" Text="Discord Client Secret" Foreground="#A7C1C8" VerticalAlignment="Center"/><PasswordBox Name="ClientSecretBox" Grid.Row="5" Grid.Column="1" Margin="6"/>
        <TextBlock Grid.Row="6" Text="Activity公開URL" Foreground="#A7C1C8" VerticalAlignment="Center"/><TextBox Name="ActivityUrlBox" Grid.Row="6" Grid.Column="1" Margin="6"/>
        <TextBlock Grid.Row="7" Text="Cloudflare Tunnel Token" Foreground="#A7C1C8" VerticalAlignment="Center"/><PasswordBox Name="TunnelTokenBox" Grid.Row="7" Grid.Column="1" Margin="6"/>
        <TextBlock Grid.Row="8" Text="オンライン人数統計" Foreground="#A7C1C8" VerticalAlignment="Center"/><CheckBox Name="PresenceCheck" Grid.Row="8" Grid.Column="1" Margin="8" VerticalAlignment="Center" Content="Presence Intentを使用する" Foreground="#C1D5DA"/>
        <TextBlock Grid.Row="9" Text="緊急連絡先暗号鍵" Foreground="#A7C1C8" VerticalAlignment="Center"/><TextBlock Grid.Row="9" Grid.Column="1" Text="「マイナス管理」タブで設定（値は非表示）" Foreground="#71939E" Margin="8"/>
       </Grid></Border><Button Name="SaveButton" Content="設定を保存" Style="{StaticResource PrimaryButton}" HorizontalAlignment="Left" Margin="0,14,0,8"/></StackPanel></ScrollViewer>
      </TabItem>
      <TabItem Header="稼働ログ"><Border Margin="14" Background="#061219" BorderBrush="#20404D" BorderThickness="1" CornerRadius="8" Padding="4"><TextBox Name="LogBox" IsReadOnly="True" AcceptsReturn="True" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" TextWrapping="NoWrap" FontFamily="Consolas" Background="#061219" Foreground="#9FE8D4" BorderThickness="0" Padding="12"/></Border></TabItem>
     </TabControl>
    </Grid>
   </ScrollViewer>
  </Border>
  <Border Grid.Row="3" Background="#091B24" BorderBrush="#163744" BorderThickness="0,1,0,0" Padding="20,0"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel Orientation="Horizontal" VerticalAlignment="Center"><Ellipse Width="7" Height="7" Fill="#29D7E9" Margin="0,0,9,0"/><TextBlock Name="StatusText" Text="停止中" FontWeight="SemiBold" Foreground="#90ADB6"/></StackPanel><StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center"><TextBlock Text="表示倍率" Foreground="#65838D" Margin="0,0,8,0"/><Slider Name="ZoomSlider" Minimum="0.75" Maximum="1.4" Value="1" TickFrequency="0.05" IsSnapToTickEnabled="True" Width="130"/><TextBlock Text="75–140%" Foreground="#47646E" Margin="8,0,0,0"/></StackPanel></Grid></Border>
 </Grid>
</Window>
'@
$reader=New-Object System.Xml.XmlNodeReader $xaml
$Window=[Windows.Markup.XamlReader]::Load($reader)
'TokenBox','GuildBox','PrefixBox','ColorBox','UpdateBox','ClientSecretBox','ActivityUrlBox','TunnelTokenBox','PresenceCheck','EmergencyKeyBox','EmergencyKeyState','MinusFeature','MinusAgreed','MinusContacts','MinusReconsent','LogBox','MemberGrid','MemberSummary','MemberSearchBox','MemberStateFilter','MemberVisibleCount','MemberTotal','MemberActive','MemberUnverified','StatusText','SaveButton','KeySaveButton','StartButton','QuickTunnelButton','HistoryScanButton','StopButton','UpdateButton','TodayMessages','MonthMessages','YearMessages','OnlineMembers','OfflineMembers','PresenceHint','HistoryScanStatus','BotHealth','RondankaiLogo','JohotaiLogo' | ForEach-Object { Set-Variable -Name $_ -Value $Window.FindName($_) }
$rondankaiLogoPath = Join-Path $script:Base 'assets\rondankai-logo.png'
$johotaiLogoPath = Join-Path $script:Base 'assets\johotai-logo.png'
function Load-UiBitmap([string]$Path) {
  if (-not (Test-Path $Path)) { throw "ロゴ画像が見つかりません：$Path" }
  $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
  $bitmap.BeginInit()
  $bitmap.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
  $bitmap.UriSource = New-Object System.Uri -ArgumentList @($Path, [System.UriKind]::Absolute)
  $bitmap.EndInit()
  $bitmap.Freeze()
  return $bitmap
}
try {
  $RondankaiLogo.Source = Load-UiBitmap $rondankaiLogoPath
  $JohotaiLogo.Source = Load-UiBitmap $johotaiLogoPath
  $Window.Icon = $JohotaiLogo.Source
} catch {
  Set-Status $_.Exception.Message 'DarkRed'
}
$envs=Read-EnvFile;$TokenBox.Password=$envs.DISCORD_BOT_TOKEN;$GuildBox.Text=$envs.DISCORD_GUILD_ID;$PrefixBox.Text=$(if($envs.CASE_PREFIX){$envs.CASE_PREFIX}else{'JHT'});$ColorBox.Text=$(if($envs.EMBED_COLOR){$envs.EMBED_COLOR}else{'00BCD4'});$UpdateBox.Text=$envs.UPDATE_MANIFEST_URL;$ClientSecretBox.Password=$envs.DISCORD_CLIENT_SECRET;$ActivityUrlBox.Text=$envs.ACTIVITY_PUBLIC_URL;$TunnelTokenBox.Password=$envs.CLOUDFLARE_TUNNEL_TOKEN;$PresenceCheck.IsChecked=($envs.ENABLE_PRESENCE_INTENT -eq 'true')
$EmergencyKeyState.Text=if($envs.EMERGENCY_DATA_KEY){'設定済み（値は非表示）'}else{'未設定'};$EmergencyKeyState.Foreground=if($envs.EMERGENCY_DATA_KEY){'#7CF3CF'}else{'#FFADBA'}
if ($script:MigrationMessage) { Set-Status $script:MigrationMessage 'Green' }
$SaveButton.Add_Click({Save-Config});$KeySaveButton.Add_Click({Save-Config});$StartButton.Add_Click({Start-AllServers});$QuickTunnelButton.Add_Click({Start-QuickTunnel});$HistoryScanButton.Add_Click({Start-HistoryScan});$StopButton.Add_Click({Stop-Bot});$UpdateButton.Add_Click({Check-Update})
$MemberSearchBox.Add_TextChanged({Apply-MemberFilter});$MemberStateFilter.Add_SelectionChanged({Apply-MemberFilter})
$timer=New-Object Windows.Threading.DispatcherTimer;$timer.Interval=[TimeSpan]::FromSeconds(2);$timer.Add_Tick({Refresh-Log});$timer.Start()
$Window.Add_Closing({if($script:BotProcess -and -not $script:BotProcess.HasExited){$answer=[System.Windows.MessageBox]::Show('管理画面を閉じてもBotは稼働を続けます。閉じますか？','確認','YesNo','Question');if($answer -ne 'Yes'){$_.Cancel=$true}}})
$Window.ShowDialog() | Out-Null
