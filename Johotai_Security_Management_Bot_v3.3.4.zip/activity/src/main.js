import { DiscordSDK } from '@discord/embedded-app-sdk';
import './style.css';

const element = id => document.getElementById(id);
let accessToken;

function fail(error) {
  element('welcome').hidden = true;
  element('dashboard').hidden = true;
  element('error').hidden = false;
  element('errorText').textContent = error?.message || String(error);
  element('connection').textContent = '接続エラー';
  element('connection').classList.add('bad');
}

function duration(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(seconds % 3600 / 60);
  return hours ? `${hours}時間${minutes}分` : `${minutes}分`;
}

function date(value) {
  return value ? new Date(value).toLocaleString('ja-JP', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '未確認';
}

function render(data) {
  element('welcome').hidden = true;
  element('error').hidden = true;
  element('dashboard').hidden = false;
  element('connection').textContent = 'LIVE';
  element('server').textContent = data.server;
  element('viewer').textContent = `${data.user.name} として接続`;
  element('members').textContent = data.summary.members;
  element('cases').textContent = data.summary.openCases;
  element('applications').textContent = data.summary.openApplications;
  element('uptime').textContent = duration(data.summary.uptimeSeconds);
  element('updated').textContent = `更新 ${new Date(data.updatedAt).toLocaleTimeString('ja-JP')}`;
  element('permission').hidden = data.authorized;
  const table = element('memberTable');
  const tbody = table.querySelector('tbody');
  table.hidden = !data.authorized;
  tbody.replaceChildren();
  for (const member of data.members || []) {
    const row = document.createElement('tr');
    const status = { active: '在籍', inactive: '休止', left: '退会' }[member.status] || member.status;
    for (const value of [member.memberId, member.codename, member.displayName, status, date(member.verifiedAt)]) {
      const cell = document.createElement('td');
      cell.textContent = value;
      row.append(cell);
    }
    tbody.append(row);
  }
}

async function load() {
  const response = await fetch('/api/dashboard', { headers: { Authorization: `Bearer ${accessToken}` } });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'データを取得できません。');
  render(data);
}

async function start() {
  const config = await fetch('/api/config').then(response => response.json());
  if (!config.clientId) throw new Error('Discord Application IDを取得できません。');
  if (!config.ready) throw new Error('管理画面でサーバーIDとDiscord Client Secretを設定してください。');
  const discordSdk = new DiscordSDK(config.clientId);
  await discordSdk.ready();
  const { code } = await discordSdk.commands.authorize({ client_id: config.clientId, response_type: 'code', state: 'johotai-monitor', prompt: 'none', scope: ['identify'] });
  const tokenResponse = await fetch('/api/token', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code }) });
  const token = await tokenResponse.json();
  if (!tokenResponse.ok) throw new Error(token.error || 'Discord認証に失敗しました。');
  accessToken = token.access_token;
  await discordSdk.commands.authenticate({ access_token: accessToken });
  await load();
  setInterval(() => load().catch(fail), 5000);
}

element('refresh').addEventListener('click', () => load().catch(fail));
start().catch(fail);
