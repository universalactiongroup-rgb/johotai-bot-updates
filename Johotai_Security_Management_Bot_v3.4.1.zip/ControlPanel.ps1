﻿Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
$ErrorActionPreference = 'Stop'
$script:Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:BotProcess = $null
$script:TunnelProcess = $null
$script:QuickTunnelMode = $false
$script:QuickTunnelReadyShown = $false
$script:QuickTunnelOut = Join-Path $script:Base 'cloudflared-output.log'
$script:QuickTunnelError = Join-Path $script:Base 'cloudflared-error.log'
$script:LogPath = Join-Path $script:Base 'bot-output.log'
$script:Version = '3.4.1'
$script:LastStatsStatusStamp = $null

function Read-EnvFile {
  $result = @{}
  $path = Join-Path $script:Base 'config.env'
  if (Test-Path $path) {
    Get-Content $path -Encoding UTF8 | ForEach-Object {
      if ($_ -match '^\s*([^#=]+)=(.*)$') { $result[$matches[1].Trim()] = $matches[2].Trim() }
    }
  }
  return $result
}
function Save-Config {
  $token = $TokenBox.Password.Trim()
  $guild = $GuildBox.Text.Trim()
  $prefix = $PrefixBox.Text.Trim()
  $color = $ColorBox.Text.Trim()
  $updateUrl = $UpdateBox.Text.Trim()
  $clientSecret = $ClientSecretBox.Password.Trim()
  $activityUrl = $ActivityUrlBox.Text.Trim()
  $tunnelToken = $TunnelTokenBox.Password.Trim()
  $presenceIntent = if ($PresenceCheck.IsChecked) { 'true' } else { 'false' }
  if ([string]::IsNullOrWhiteSpace($prefix)) { $prefix = 'JHT' }
  if ([string]::IsNullOrWhiteSpace($color)) { $color = '00BCD4' }
  $content = "DISCORD_BOT_TOKEN=$token`r`nDISCORD_GUILD_ID=$guild`r`nCASE_PREFIX=$prefix`r`nEMBED_COLOR=$color`r`nUPDATE_MANIFEST_URL=$updateUrl`r`nDISCORD_CLIENT_SECRET=$clientSecret`r`nACTIVITY_PORT=3000`r`nACTIVITY_PUBLIC_URL=$activityUrl`r`nCLOUDFLARE_TUNNEL_TOKEN=$tunnelToken`r`nENABLE_PRESENCE_INTENT=$presenceIntent`r`n"
  $utf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
  [System.IO.File]::WriteAllText((Join-Path $script:Base 'config.env'), $content, $utf8)
  Set-Status '設定を保存しました。' 'Green'
}
function Set-Status([string]$Text,[string]$Color='Gray') { $StatusText.Text=$Text; $StatusText.Foreground=$Color }
function Wait-ProcessWithUi($Process,[string]$Label,[int]$TimeoutSeconds=600) {
  $watch = [System.Diagnostics.Stopwatch]::StartNew()
  while (-not $Process.HasExited) {
    if ($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds) {
      Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
      throw "$Label が $TimeoutSeconds 秒以内に完了しなかったため中止しました。"
    }
    Set-Status "$Label… $([math]::Floor($watch.Elapsed.TotalSeconds))秒" 'DarkOrange'
    $Window.Dispatcher.Invoke([Action]{},[System.Windows.Threading.DispatcherPriority]::Background)
    Start-Sleep -Milliseconds 250
  }
  return $Process.ExitCode
}
function Test-ActivityServer {
  try {
    $response = Invoke-WebRequest 'http://127.0.0.1:3000/api/config' -UseBasicParsing -TimeoutSec 2
    return $response.StatusCode -eq 200
  } catch { return $false }
}
function Refresh-Log {
  if (Test-Path $script:LogPath) {
    $all = @(Get-Content $script:LogPath -Encoding UTF8 -Tail 250 -ErrorAction SilentlyContinue)
    $LogBox.Text = $all -join "`r`n"
    $LogBox.ScrollToEnd()
  }
  if ($script:BotProcess -and $script:BotProcess.HasExited) {
    Set-Status "Botは停止しています（終了コード $($script:BotProcess.ExitCode)）。" 'DarkRed'
    $script:BotProcess=$null
  }
  Refresh-QuickTunnel
  Refresh-Members
  Refresh-HistoryScan
}
function Start-HistoryScan {
  try {
    if (-not (Test-ActivityServer)) { throw '先にBotを起動してください。' }
    $guildId = $GuildBox.Text.Trim()
    if ($guildId -notmatch '^\d{17,20}$') { throw 'サーバーIDを設定して保存してください。' }
    $dataDir = Join-Path $script:Base 'data'
    New-Item $dataDir -ItemType Directory -Force | Out-Null
    $statusPath = Join-Path $dataDir 'stats-rebuild.status.json'
    if (Test-Path $statusPath) { Remove-Item $statusPath -Force }
    $request = @{ guildId=$guildId; requestedAt=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json
    $utf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
    [System.IO.File]::WriteAllText((Join-Path $dataDir 'stats-rebuild.request.json'), $request, $utf8)
    $script:LastStatsStatusStamp = $null
    $HistoryScanStatus.Text = 'Botへ集計を依頼しました。まもなく開始します…'
    Set-Status '過去統計の集計を依頼しました。通常運用はそのまま継続できます。' 'DarkOrange'
  } catch {
    Set-Status $_.Exception.Message 'DarkRed'
    [System.Windows.MessageBox]::Show($_.Exception.Message,'過去統計エラー','OK','Error') | Out-Null
  }
}
function Refresh-HistoryScan {
  $path = Join-Path $script:Base 'data\stats-rebuild.status.json'
  if (-not (Test-Path $path)) { return }
  try {
    $status = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $status.updatedAt -or $script:LastStatsStatusStamp -eq $status.updatedAt) { return }
    $script:LastStatsStatusStamp = $status.updatedAt
    if ($status.state -eq 'running') {
      $text = "集計中：#$($status.channel)　チャンネル $($status.completedChannels)/$($status.totalChannels)　読取 $([int64]$status.scannedMessages)件"
      $HistoryScanStatus.Text = $text
      Set-Status $text 'DarkOrange'
    } elseif ($status.state -eq 'completed') {
      $text = "$($status.year)年の過去統計を反映しました。読取 $([int64]$status.scannedMessages)件／対象外 $([int]$status.skippedChannels)チャンネル"
      $HistoryScanStatus.Text = $text
      Set-Status $text 'Green'
    } elseif ($status.state -eq 'failed') {
      $text = "過去統計の集計に失敗しました：$($status.message)"
      $HistoryScanStatus.Text = $text
      Set-Status $text 'DarkRed'
    }
  } catch { }
}
function Refresh-QuickTunnel {
  if (-not $script:QuickTunnelMode -or $script:QuickTunnelReadyShown) { return }
  $text = ''
  foreach ($path in @($script:QuickTunnelOut,$script:QuickTunnelError)) {
    if (Test-Path $path) { $text += "`n" + (Get-Content $path -Raw -Encoding UTF8 -ErrorAction SilentlyContinue) }
  }
  if ($text -match 'https://([a-z0-9-]+\.trycloudflare\.com)') {
    $url = $matches[0]
    $hostName = $matches[1]
    $script:QuickTunnelReadyShown = $true
    $ActivityUrlBox.Text = $url
    Save-Config
    [System.Windows.Clipboard]::SetText($hostName)
    Set-Status "無料Activity接続が準備できました：$hostName" 'Green'
    [System.Windows.MessageBox]::Show("公開先ができました。`n`n$hostName`n`nホスト名はコピー済みです。Discord Developer Portal の Activities → URL Mappings で、Prefix『/』の Targetへ貼り付けてください。`n`nこの無料URLは接続を開始し直すと変わります。",'Activity接続の準備完了','OK','Information') | Out-Null
  } elseif ($script:TunnelProcess -and $script:TunnelProcess.HasExited) {
    $script:QuickTunnelMode = $false
    Set-Status '無料Activity接続を開始できませんでした。cloudflared-error.logを確認してください。' 'DarkRed'
  }
}
function Refresh-Members {
  $path = Join-Path $script:Base 'data\database.json'
  if (-not (Test-Path $path)) { $MemberSummary.Text='会員データはまだありません。'; $MemberGrid.ItemsSource=@(); Update-Dashboard $null; return }
  try {
    $db = Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json
    $guildProperty = $null
    $guildId = $GuildBox.Text.Trim()
    if ($guildId) { $guildProperty = $db.guilds.PSObject.Properties[$guildId] }
    if (-not $guildProperty) { $guildProperty = $db.guilds.PSObject.Properties | Select-Object -First 1 }
    $guildData = if ($guildProperty) { $guildProperty.Value } else { $null }
    Update-Dashboard $guildData
    $items = @()
    if ($guildProperty -and $guildProperty.Value.community.members) {
      foreach ($property in $guildProperty.Value.community.members.PSObject.Properties) {
        $member = $property.Value
        $status = switch ($member.status) { 'active' {'在籍'} 'inactive' {'休止'} 'left' {'退会'} default {$member.status} }
        $verified = if ($member.verifiedAt) { ([datetime]$member.verifiedAt).ToLocalTime().ToString('yyyy/MM/dd HH:mm') } else { '未確認' }
        $items += [PSCustomObject]@{会員番号=$member.memberId;コードネーム=$member.codename;Discord表示名=$(if($member.displayName){$member.displayName}else{$member.discordUsername});在籍状態=$status;本人確認=$verified;DiscordID=$member.userId}
      }
    }
    $MemberGrid.ItemsSource = @($items | Sort-Object 会員番号)
    $active = @($items | Where-Object {$_.在籍状態 -eq '在籍'}).Count
    $MemberSummary.Text = "登録 $($items.Count)名　／　在籍 ${active}名　／　最終更新 $(Get-Date -Format 'HH:mm:ss')"
  } catch { $MemberSummary.Text="会員データの読込待機中：$($_.Exception.Message)" }
}
function Update-Dashboard($GuildData) {
  $TodayMessages.Text = '0'; $MonthMessages.Text = '0'; $YearMessages.Text = '0'; $OnlineMembers.Text = '—'; $OfflineMembers.Text = '—'
  $running = Test-ActivityServer
  $BotHealth.Text = if ($running) { '稼働中' } else { '停止中' }
  $BotHealth.Foreground = if ($running) { '#15966A' } else { '#C74759' }
  if (-not $GuildData) { $PresenceHint.Text = '統計データはまだありません。'; return }
  $now = Get-Date
  $todayKey = $now.ToString('yyyy-MM-dd')
  $monthKey = $now.ToString('yyyy-MM')
  $yearKey = $now.ToString('yyyy')
  $days = $GuildData.analytics.messages.byDay
  if ($days) {
    $today = 0; $month = 0; $year = 0
    foreach ($property in $days.PSObject.Properties) {
      $count = [int64]$property.Value
      if ($property.Name -eq $todayKey) { $today += $count }
      if ($property.Name.StartsWith($monthKey)) { $month += $count }
      if ($property.Name.StartsWith($yearKey)) { $year += $count }
    }
    $TodayMessages.Text = $today.ToString('N0'); $MonthMessages.Text = $month.ToString('N0'); $YearMessages.Text = $year.ToString('N0')
  }
  $presence = $GuildData.analytics.presence
  if ($presence.enabled) {
    $OnlineMembers.Text = ([int]$presence.online).ToString('N0')
    $OfflineMembers.Text = ([int]$presence.offline).ToString('N0')
    $PresenceHint.Text = "Discord接続状況を自動更新中　／　対象 $($presence.total)名"
  } else {
    $PresenceHint.Text = 'オンライン統計を使うには、Discord Developer PortalのServer Members IntentとPresence Intentを有効にして、設定欄にもチェックを入れてください。'
  }
}
function Ensure-Node {
  if (Get-Command node.exe -ErrorAction SilentlyContinue) { return $true }
  Set-Status 'Node.jsを自動インストールしています…' 'DarkOrange'
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if ($winget) {
    $p=Start-Process winget.exe -ArgumentList 'install --id OpenJS.NodeJS.LTS --exact --silent --accept-package-agreements --accept-source-agreements' -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Node.jsの導入に失敗しました（winget: $($p.ExitCode)）。" }
  } else {
    $index=Invoke-RestMethod 'https://nodejs.org/dist/index.json'
    $release=$index | Where-Object {$_.lts -and $_.files -contains 'win-x64-msi'} | Select-Object -First 1
    if (-not $release) { throw 'Node.js LTSの配布情報を取得できません。' }
    $msi=Join-Path $env:TEMP "node-$($release.version)-x64.msi"
    Invoke-WebRequest "https://nodejs.org/dist/$($release.version)/node-$($release.version)-x64.msi" -OutFile $msi
    $p=Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "Node.jsの導入に失敗しました（MSI: $($p.ExitCode)）。" }
  }
  $env:Path += ';' + ${env:ProgramFiles} + '\nodejs'
  return [bool](Get-Command node.exe -ErrorAction SilentlyContinue)
}
function Ensure-Packages {
  if ((Test-Path (Join-Path $script:Base 'node_modules\discord.js')) -and (Test-Path (Join-Path $script:Base 'node_modules\pdfkit'))) { return }
  Set-Status '必要なプログラムをインストールしています…' 'DarkOrange'
  $npm=(Get-Command npm.cmd -ErrorAction Stop).Source
  $p=Start-Process $npm -ArgumentList 'ci --omit=dev --loglevel=error --no-audit --no-fund --prefer-offline' -WorkingDirectory $script:Base -PassThru -WindowStyle Hidden -RedirectStandardOutput $script:LogPath -RedirectStandardError (Join-Path $script:Base 'startup-error.log')
  $exitCode = Wait-ProcessWithUi $p 'Bot用パッケージをインストールしています' 600
  if ($exitCode -ne 0) { throw '必要なファイルのインストールに失敗しました。startup-error.logを確認してください。' }
  Set-Status 'Bot用パッケージのインストールが完了しました。' 'Green'
}
function Test-CloudflaredBinary([string]$Path) {
  if (-not (Test-Path $Path -PathType Leaf)) { return $false }
  try {
    $signature = Get-AuthenticodeSignature $Path
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notlike '*Cloudflare*') { return $false }
    $test = Start-Process $Path -ArgumentList '--version' -Wait -PassThru -WindowStyle Hidden
    return $test.ExitCode -eq 0
  } catch { return $false }
}
function Ensure-Cloudflared {
  $command = Get-Command cloudflared.exe -ErrorAction SilentlyContinue
  if ($command -and (Test-CloudflaredBinary $command.Source)) { return $command.Source }
  $local = Join-Path $script:Base 'tools\cloudflared.exe'
  if (Test-CloudflaredBinary $local) { return $local }
  if (Test-Path $local) { Remove-Item $local -Force }
  Set-Status 'Activity用のCloudflare Tunnelを自動インストールしています…' 'DarkOrange'
  New-Item (Split-Path $local -Parent) -ItemType Directory -Force | Out-Null
  $architecture = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
  $asset = switch ($architecture) { 'Arm64' {'cloudflared-windows-arm64.exe'} 'X86' {'cloudflared-windows-386.exe'} default {'cloudflared-windows-amd64.exe'} }
  $download = Join-Path (Split-Path $local -Parent) 'cloudflared.download.exe'
  if (Test-Path $download) { Remove-Item $download -Force }
  try {
    Invoke-WebRequest "https://github.com/cloudflare/cloudflared/releases/latest/download/$asset" -OutFile $download -UseBasicParsing -TimeoutSec 180
    if (-not (Test-CloudflaredBinary $download)) { throw "このPC（$architecture）で実行できるCloudflare公式ファイルではありません。" }
    Move-Item $download $local -Force
  } finally {
    if (Test-Path $download) { Remove-Item $download -Force }
  }
  return $local
}
function Start-ActivityTunnel {
  $token = $TunnelTokenBox.Password.Trim()
  if (-not $token) { return }
  if ($token -notmatch '^[A-Za-z0-9._=-]+$') { throw 'Cloudflare Tunnelトークンの形式が正しくありません。' }
  if ($script:TunnelProcess -and -not $script:TunnelProcess.HasExited) { return }
  $cloudflared = Ensure-Cloudflared
  $info = New-Object System.Diagnostics.ProcessStartInfo
  $info.FileName = $cloudflared
  $info.Arguments = "tunnel run --token $token"
  $info.WorkingDirectory = $script:Base
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $script:TunnelProcess = [System.Diagnostics.Process]::Start($info)
}
function Start-QuickTunnel {
  try {
    if (-not (Test-ActivityServer)) {
      Start-Bot
      for ($attempt = 0; $attempt -lt 30 -and -not (Test-ActivityServer); $attempt++) { Start-Sleep -Milliseconds 500 }
      if (-not (Test-ActivityServer)) { throw 'BotのActivityサーバーを確認できません。稼働ログを確認してください。' }
    }
    if ($script:TunnelProcess -and -not $script:TunnelProcess.HasExited) {
      Stop-Process -Id $script:TunnelProcess.Id
      $script:TunnelProcess.WaitForExit()
    }
    $cloudflared = Ensure-Cloudflared
    foreach ($path in @($script:QuickTunnelOut,$script:QuickTunnelError)) {
      if (Test-Path $path) { Remove-Item $path -Force }
    }
    $port = 3000
    $script:QuickTunnelMode = $true
    $script:QuickTunnelReadyShown = $false
    $script:TunnelProcess = Start-Process $cloudflared -ArgumentList "tunnel --url http://127.0.0.1:$port --no-autoupdate" -WorkingDirectory $script:Base -PassThru -WindowStyle Hidden -RedirectStandardOutput $script:QuickTunnelOut -RedirectStandardError $script:QuickTunnelError
    Set-Status '無料Activity接続を準備しています…（通常10～30秒）' 'DarkOrange'
  } catch {
    $script:QuickTunnelMode = $false
    Set-Status $_.Exception.Message 'DarkRed'
    [System.Windows.MessageBox]::Show($_.Exception.Message,'Activity接続エラー','OK','Error') | Out-Null
  }
}
function Start-Bot {
  try {
    Save-Config
    if (-not $TokenBox.Password.Trim() -or $TokenBox.Password -like '*ここにBotトークン*') { throw 'Botトークンを入力してください。' }
    if (Test-ActivityServer) { Set-Status 'Botは既に起動しています。' 'Green'; return }
    if (-not (Ensure-Node)) { throw 'Node.jsを確認できません。Windowsを再起動してからお試しください。' }
    Ensure-Packages
    Start-ActivityTunnel
    if ($script:BotProcess -and -not $script:BotProcess.HasExited) { Set-Status 'Botは既に起動しています。' 'Green'; return }
    $utf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
    [System.IO.File]::WriteAllText($script:LogPath, "[$(Get-Date)] Botを起動します。`r`n", $utf8)
    $node=(Get-Command node.exe -ErrorAction Stop).Source
    $script:BotProcess=Start-Process $node -ArgumentList 'bot.js' -WorkingDirectory $script:Base -PassThru -WindowStyle Hidden -RedirectStandardOutput $script:LogPath -RedirectStandardError (Join-Path $script:Base 'startup-error.log')
    Set-Status "Botを起動しました（PID $($script:BotProcess.Id)）。" 'Green'
  } catch { Set-Status $_.Exception.Message 'DarkRed'; [System.Windows.MessageBox]::Show($_.Exception.Message,'起動エラー','OK','Error') | Out-Null }
}
function Stop-Bot {
  if ($script:BotProcess -and -not $script:BotProcess.HasExited) { Stop-Process -Id $script:BotProcess.Id; $script:BotProcess.WaitForExit(); $script:BotProcess=$null }
  if ($script:TunnelProcess -and -not $script:TunnelProcess.HasExited) { Stop-Process -Id $script:TunnelProcess.Id; $script:TunnelProcess=$null }
  $script:QuickTunnelMode = $false
  $script:QuickTunnelReadyShown = $false
  Set-Status 'Botを停止しました。' 'DarkRed'
}
function Check-Update {
  try {
    Save-Config
    $url=$UpdateBox.Text.Trim()
    if (-not $url.StartsWith('https://')) { throw '更新マニフェストにはHTTPSのURLを設定してください。' }
    Set-Status '更新情報を確認しています…' 'DarkOrange'
    $m=Invoke-RestMethod $url
    if (-not $m.version -or -not $m.url -or $m.sha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw '更新情報のversion、url、sha256が正しくありません。' }
    if ([version]$m.version -le [version]$script:Version) { Set-Status "最新版です（v$script:Version）。" 'Green'; return }
    $answer=[System.Windows.MessageBox]::Show("v$($m.version)があります。設定とデータを残して更新しますか？",'更新','YesNo','Question')
    if ($answer -ne 'Yes') { Set-Status '更新をキャンセルしました。'; return }
    $zip=Join-Path $env:TEMP "JohotaiBot-$($m.version).zip"
    Invoke-WebRequest ([string]$m.url) -OutFile $zip
    $actual=(Get-FileHash $zip -Algorithm SHA256).Hash
    if ($actual -ne ([string]$m.sha256).ToUpperInvariant()) { Remove-Item $zip -Force; throw '更新ファイルのSHA256が一致しないため中止しました。' }
    Stop-Bot
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $script:Base 'Update-Bot.ps1')`" -ZipPath `"$zip`" -InstallDir `"$script:Base`" -WaitPid $PID" -WindowStyle Hidden
    $Window.Close()
  } catch { Set-Status $_.Exception.Message 'DarkRed'; [System.Windows.MessageBox]::Show($_.Exception.Message,'更新エラー','OK','Error') | Out-Null }
}

[xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="情報保安対策委員会 Bot 管理センター" Height="920" Width="1080" MinHeight="760" MinWidth="860" WindowStartupLocation="CenterScreen" Background="#EEF4F6">
 <Grid Margin="22"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
  <StackPanel><TextBlock Text="情報保安対策委員会 Bot" FontSize="27" FontWeight="Bold" Foreground="#123B4A"/><TextBlock Text="SECURITY OPERATIONS CONTROL CENTER" FontSize="10" CharacterSpacing="180" Foreground="#289BAD" Margin="0,3,0,2"/><TextBlock Text="統計・会員・接続・ログをリアルタイムで一元管理" Foreground="#52616B" Margin="0,2,0,16"/></StackPanel>
  <Border Grid.Row="1" Background="White" CornerRadius="12" Padding="18" BorderBrush="#CDE1E5" BorderThickness="1"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="190"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
   <TextBlock Text="Botトークン" VerticalAlignment="Center"/><PasswordBox Name="TokenBox" Grid.Column="1" Margin="8" Padding="7"/>
   <TextBlock Grid.Row="1" Text="サーバーID（任意）" VerticalAlignment="Center"/><TextBox Name="GuildBox" Grid.Row="1" Grid.Column="1" Margin="8" Padding="7"/>
   <TextBlock Grid.Row="2" Text="受付番号の接頭辞" VerticalAlignment="Center"/><TextBox Name="PrefixBox" Grid.Row="2" Grid.Column="1" Margin="8" Padding="7" Text="JHT"/>
   <TextBlock Grid.Row="3" Text="テーマ色" VerticalAlignment="Center"/><TextBox Name="ColorBox" Grid.Row="3" Grid.Column="1" Margin="8" Padding="7" Text="00BCD4"/>
   <TextBlock Grid.Row="4" Text="更新情報URL" VerticalAlignment="Center"/><TextBox Name="UpdateBox" Grid.Row="4" Grid.Column="1" Margin="8" Padding="7"/>
   <TextBlock Grid.Row="5" Text="Discord Client Secret" VerticalAlignment="Center"/><PasswordBox Name="ClientSecretBox" Grid.Row="5" Grid.Column="1" Margin="8" Padding="7"/>
   <TextBlock Grid.Row="6" Text="Activity公開URL" VerticalAlignment="Center"/><TextBox Name="ActivityUrlBox" Grid.Row="6" Grid.Column="1" Margin="8" Padding="7"/>
   <TextBlock Grid.Row="7" Text="Cloudflare Tunnel Token" VerticalAlignment="Center"/><PasswordBox Name="TunnelTokenBox" Grid.Row="7" Grid.Column="1" Margin="8" Padding="7"/>
   <TextBlock Grid.Row="8" Text="オンライン人数統計" VerticalAlignment="Center"/><CheckBox Name="PresenceCheck" Grid.Row="8" Grid.Column="1" Margin="8" VerticalAlignment="Center" Content="Presence Intentを使用する（Portal側の有効化が必要）" Foreground="#334E57"/>
  </Grid></Border>
  <Grid Grid.Row="2" Margin="0,16,0,0"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><WrapPanel><Button Name="SaveButton" Content="設定を保存" Padding="18,9" Margin="0,0,8,8"/><Button Name="StartButton" Content="Botを起動" Padding="18,9" Margin="0,0,8,8" Background="#00BCD4" Foreground="White"/><Button Name="QuickTunnelButton" Content="無料Activity接続" Padding="18,9" Margin="0,0,8,8" Background="#5865F2" Foreground="White" ToolTip="アカウント・ドメイン・トークン不要の一時HTTPS接続"/><Button Name="HistoryScanButton" Content="過去統計を集計" Padding="18,9" Margin="0,0,8,8" Background="#126D7C" Foreground="White" ToolTip="今年1月1日以降の投稿を読み直して統計へ反映"/><Button Name="StopButton" Content="停止" Padding="18,9" Margin="0,0,8,8"/><Button Name="UpdateButton" Content="更新を確認" Padding="18,9" Margin="0,0,8,8"/></WrapPanel>
   <TabControl Grid.Row="1" Background="White" BorderBrush="#BCD8DD"><TabItem Header="ダッシュボード"><ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel Margin="16">
     <DockPanel Margin="0,0,0,16"><StackPanel><TextBlock Text="運用ダッシュボード" FontSize="21" FontWeight="Bold" Foreground="#123B4A"/><TextBlock Text="日本時間を基準に約2秒ごとに更新" Foreground="#6A858D"/></StackPanel><Border DockPanel.Dock="Right" Background="#E5F8F2" CornerRadius="16" Padding="14,7" HorizontalAlignment="Right"><TextBlock Name="BotHealth" Text="確認中" FontWeight="Bold" Foreground="#15966A"/></Border></DockPanel>
     <UniformGrid Columns="3" Margin="0,0,0,12"><Border Background="#0F3B47" CornerRadius="10" Padding="18" Margin="5"><StackPanel><TextBlock Text="今日のメッセージ" Foreground="#9BC7D0"/><TextBlock Name="TodayMessages" Text="0" FontSize="32" FontWeight="Bold" Foreground="White"/><TextBlock Text="TODAY" FontSize="9" Foreground="#38D5E7"/></StackPanel></Border><Border Background="#0F3B47" CornerRadius="10" Padding="18" Margin="5"><StackPanel><TextBlock Text="今月のメッセージ" Foreground="#9BC7D0"/><TextBlock Name="MonthMessages" Text="0" FontSize="32" FontWeight="Bold" Foreground="White"/><TextBlock Text="THIS MONTH" FontSize="9" Foreground="#38D5E7"/></StackPanel></Border><Border Background="#0F3B47" CornerRadius="10" Padding="18" Margin="5"><StackPanel><TextBlock Text="今年のメッセージ" Foreground="#9BC7D0"/><TextBlock Name="YearMessages" Text="0" FontSize="32" FontWeight="Bold" Foreground="White"/><TextBlock Text="THIS YEAR" FontSize="9" Foreground="#38D5E7"/></StackPanel></Border></UniformGrid>
     <UniformGrid Columns="2"><Border Background="#E7F8F2" BorderBrush="#A9E8D2" BorderThickness="1" CornerRadius="10" Padding="18" Margin="5"><StackPanel><TextBlock Text="●  オンライン" Foreground="#15966A"/><TextBlock Name="OnlineMembers" Text="—" FontSize="32" FontWeight="Bold" Foreground="#123B4A"/></StackPanel></Border><Border Background="#F0F3F4" BorderBrush="#D2DEE1" BorderThickness="1" CornerRadius="10" Padding="18" Margin="5"><StackPanel><TextBlock Text="●  オフライン" Foreground="#758A91"/><TextBlock Name="OfflineMembers" Text="—" FontSize="32" FontWeight="Bold" Foreground="#123B4A"/></StackPanel></Border></UniformGrid>
     <TextBlock Name="PresenceHint" Text="接続状況を確認しています…" TextWrapping="Wrap" Foreground="#647D85" Margin="6,10,6,0"/>
     <Border Background="#EAF5F7" BorderBrush="#C3E1E6" BorderThickness="1" CornerRadius="8" Padding="12" Margin="6,12,6,0"><StackPanel><TextBlock Text="過去メッセージ統計" FontWeight="Bold" Foreground="#123B4A"/><TextBlock Name="HistoryScanStatus" Text="「過去統計を集計」で、今年1月1日以降の投稿を読み取れます。" TextWrapping="Wrap" Foreground="#526D75" Margin="0,4,0,0"/></StackPanel></Border>
    </StackPanel></ScrollViewer></TabItem><TabItem Header="稼働ログ"><TextBox Name="LogBox" IsReadOnly="True" AcceptsReturn="True" VerticalScrollBarVisibility="Auto" TextWrapping="Wrap" FontFamily="Consolas" Background="#102A33" Foreground="#D7EEF2" Padding="12"/></TabItem>
    <TabItem Header="会員モニター"><Grid Margin="8"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><TextBlock Name="MemberSummary" Text="会員データを読み込んでいます…" FontWeight="SemiBold" Foreground="#123B4A" Margin="4,4,4,10"/><DataGrid Name="MemberGrid" Grid.Row="1" IsReadOnly="True" AutoGenerateColumns="False" CanUserAddRows="False" HeadersVisibility="Column" AlternatingRowBackground="#EAF7F9" GridLinesVisibility="Horizontal"><DataGrid.Columns><DataGridTextColumn Header="会員番号" Binding="{Binding 会員番号}" Width="95"/><DataGridTextColumn Header="コードネーム" Binding="{Binding コードネーム}" Width="140"/><DataGridTextColumn Header="Discord表示名" Binding="{Binding Discord表示名}" Width="160"/><DataGridTextColumn Header="状態" Binding="{Binding 在籍状態}" Width="70"/><DataGridTextColumn Header="本人確認日時" Binding="{Binding 本人確認}" Width="145"/><DataGridTextColumn Header="Discord ID" Binding="{Binding DiscordID}" Width="*"/></DataGrid.Columns></DataGrid></Grid></TabItem>
   </TabControl>
  </Grid>
  <TextBlock Name="StatusText" Grid.Row="3" Text="停止中" FontWeight="SemiBold" Foreground="DarkRed" Margin="0,12,0,0"/>
 </Grid>
</Window>
'@
$reader=New-Object System.Xml.XmlNodeReader $xaml
$Window=[Windows.Markup.XamlReader]::Load($reader)
'TokenBox','GuildBox','PrefixBox','ColorBox','UpdateBox','ClientSecretBox','ActivityUrlBox','TunnelTokenBox','PresenceCheck','LogBox','MemberGrid','MemberSummary','StatusText','SaveButton','StartButton','QuickTunnelButton','HistoryScanButton','StopButton','UpdateButton','TodayMessages','MonthMessages','YearMessages','OnlineMembers','OfflineMembers','PresenceHint','HistoryScanStatus','BotHealth' | ForEach-Object { Set-Variable -Name $_ -Value $Window.FindName($_) }
$envs=Read-EnvFile;$TokenBox.Password=$envs.DISCORD_BOT_TOKEN;$GuildBox.Text=$envs.DISCORD_GUILD_ID;$PrefixBox.Text=$(if($envs.CASE_PREFIX){$envs.CASE_PREFIX}else{'JHT'});$ColorBox.Text=$(if($envs.EMBED_COLOR){$envs.EMBED_COLOR}else{'00BCD4'});$UpdateBox.Text=$envs.UPDATE_MANIFEST_URL;$ClientSecretBox.Password=$envs.DISCORD_CLIENT_SECRET;$ActivityUrlBox.Text=$envs.ACTIVITY_PUBLIC_URL;$TunnelTokenBox.Password=$envs.CLOUDFLARE_TUNNEL_TOKEN;$PresenceCheck.IsChecked=($envs.ENABLE_PRESENCE_INTENT -eq 'true')
$SaveButton.Add_Click({Save-Config});$StartButton.Add_Click({Start-Bot});$QuickTunnelButton.Add_Click({Start-QuickTunnel});$HistoryScanButton.Add_Click({Start-HistoryScan});$StopButton.Add_Click({Stop-Bot});$UpdateButton.Add_Click({Check-Update})
$timer=New-Object Windows.Threading.DispatcherTimer;$timer.Interval=[TimeSpan]::FromSeconds(2);$timer.Add_Tick({Refresh-Log});$timer.Start()
$Window.Add_Closing({if($script:BotProcess -and -not $script:BotProcess.HasExited){$answer=[System.Windows.MessageBox]::Show('管理画面を閉じてもBotは稼働を続けます。閉じますか？','確認','YesNo','Question');if($answer -ne 'Yes'){$_.Cancel=$true}}})
$Window.ShowDialog() | Out-Null
