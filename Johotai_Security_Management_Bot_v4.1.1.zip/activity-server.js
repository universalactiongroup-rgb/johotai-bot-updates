import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { dirname, extname, join, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { PermissionFlagsBits } from 'discord.js';

const root = join(dirname(fileURLToPath(import.meta.url)), 'activity', 'dist');
const contentTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json; charset=utf-8' };
const authCache = new Map();

function tokyoDateKey(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en', { timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  const value = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

function messageSummary(store) {
  const messages = store.analytics?.messages || {};
  const byDay = messages.byDay || {};
  const today = tokyoDateKey();
  const month = today.slice(0, 7);
  const year = today.slice(0, 4);
  const sum = prefix => Object.entries(byDay).reduce((total, [key, count]) => total + (key.startsWith(prefix) ? Number(count) || 0 : 0), 0);
  return { today: Number(byDay[today]) || 0, month: sum(month), year: sum(year), total: Number(messages.total) || 0, trackingSince: messages.trackingSince || null };
}

function sendJson(res, status, data) {
  const value = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(value) });
  res.end(value);
}

async function requestBody(req) {
  let value = '';
  for await (const chunk of req) {
    value += chunk;
    if (value.length > 10000) throw new Error('request too large');
  }
  return JSON.parse(value || '{}');
}

async function getDiscordUser(req) {
  const authorization = req.headers.authorization;
  if (!authorization?.startsWith('Bearer ')) return null;
  const cached = authCache.get(authorization);
  if (cached?.expiresAt > Date.now()) return cached.user;
  const response = await fetch('https://discord.com/api/v10/users/@me', { headers: { Authorization: authorization } });
  if (!response.ok) return null;
  const user = await response.json();
  if (authCache.size > 5000) authCache.clear();
  authCache.set(authorization, { user, expiresAt: Date.now() + 60000 });
  return user;
}

export function startActivityServer({ client, guildStore, getMinusStatus }) {
  const port = Number(process.env.ACTIVITY_PORT || 3000);
  const clientSecret = process.env.DISCORD_CLIENT_SECRET?.trim();
  const configuredGuild = process.env.DISCORD_GUILD_ID?.trim();
  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      if (req.method === 'GET' && url.pathname === '/api/config') {
        return sendJson(res, 200, { clientId: client.application.id, guildId: configuredGuild || null, ready: Boolean(clientSecret && configuredGuild) });
      }
      if (req.method === 'POST' && url.pathname === '/api/token') {
        if (!clientSecret) return sendJson(res, 503, { error: 'Discord Client Secretが設定されていません。' });
        const { code } = await requestBody(req);
        if (!code) return sendJson(res, 400, { error: '認証コードがありません。' });
        const form = new URLSearchParams({ client_id: client.application.id, client_secret: clientSecret, grant_type: 'authorization_code', code: String(code) });
        const response = await fetch('https://discord.com/api/v10/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form });
        const token = await response.json();
        if (!response.ok) return sendJson(res, 401, { error: 'Discord認証に失敗しました。' });
        return sendJson(res, 200, { access_token: token.access_token, expires_in: token.expires_in });
      }
      if (req.method === 'GET' && url.pathname === '/api/dashboard') {
        const user = await getDiscordUser(req);
        if (!user) return sendJson(res, 401, { error: 'Discordでの認証が必要です。' });
        if (!configuredGuild) return sendJson(res, 503, { error: 'DISCORD_GUILD_IDが設定されていません。' });
        const guild = await client.guilds.fetch(configuredGuild).catch(() => null);
        if (!guild) return sendJson(res, 404, { error: '対象サーバーが見つかりません。' });
        const member = await guild.members.fetch(user.id).catch(() => null);
        if (!member) return sendJson(res, 403, { error: '対象サーバーの会員だけが利用できます。' });
        const store = guildStore(guild.id);
        const committeeRoleId = store.config?.roleId;
        const authorized = Boolean(member.permissions.has(PermissionFlagsBits.ManageGuild) || (committeeRoleId && member.roles.cache.has(committeeRoleId)));
        if (!authorized) return sendJson(res, 403, { error: '情報保安対策委員会の役職が必要です。' });
        const community = store.community || {};
        const members = Object.values(community.members || {});
        const cases = Object.values(store.cases || {});
        const applications = Object.values(community.applications || {});
        const messageStats = messageSummary(store);
        const presence = store.analytics?.presence || { enabled: false, online: null, offline: null, total: guild.memberCount };
        const result = {
          server: guild.name,
          user: { name: member.displayName },
          authorized: true,
          summary: {
            members: members.filter(item => item.status === 'active').length,
            openCases: cases.filter(item => !['closed', 'cancelled'].includes(item.status)).length,
            openApplications: applications.filter(item => ['submitted', 'reviewing', 'returned'].includes(item.status)).length,
            uptimeSeconds: Math.floor(process.uptime()),
            messages: messageStats,
            presence,
          },
          updatedAt: new Date().toISOString(),
        };
        result.members = members.sort((a, b) => String(a.memberId).localeCompare(String(b.memberId))).map(item => {
          const guildMember = guild.members.cache.get(item.userId);
          return { memberId: item.memberId, codename: item.codename || '未設定', displayName: item.displayName || item.discordUsername || '不明', status: item.status || 'active', verifiedAt: item.verifiedAt || null, onlineStatus: presence.enabled ? (guildMember?.presence?.status || 'offline') : null };
        });
        return sendJson(res, 200, result);
      }
      if (req.method !== 'GET') return sendJson(res, 405, { error: 'Method Not Allowed' });
      const relative = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname.slice(1));
      let target = normalize(join(root, relative));
      if ((target !== root && !target.startsWith(`${root}${sep}`)) || !existsSync(target) || statSync(target).isDirectory()) target = join(root, 'index.html');
      if (!existsSync(target)) return sendJson(res, 503, { error: 'Activity画面が未ビルドです。' });
      res.writeHead(200, { 'Content-Type': contentTypes[extname(target)] || 'application/octet-stream', 'Cache-Control': extname(target) === '.html' ? 'no-store' : 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' });
      createReadStream(target).pipe(res);
    } catch (error) {
      console.error('Activity API:', error);
      if (!res.headersSent) sendJson(res, 500, { error: 'Activityサーバーでエラーが発生しました。' });
      else res.end();
    }
  });
  server.listen(port, '127.0.0.1', () => console.log(`Discord Activityサーバーを http://127.0.0.1:${port} で起動しました。`));
  server.on('error', error => console.error('Discord Activityサーバーを起動できません:', error.message));
  const controlServer = createServer(async (req, res) => {
    try {
      if (req.method !== 'GET' || req.url !== '/api/control-panel') return sendJson(res, 404, { error: 'Not Found' });
      let guild = configuredGuild ? await client.guilds.fetch(configuredGuild).catch(() => null) : null;
      guild ||= client.guilds.cache.first() || null;
      if (!guild) return sendJson(res, 404, { error: '接続中のサーバーがありません。' });
      const store = guildStore(guild.id);
      const members = Object.values(store.community?.members || {});
      return sendJson(res, 200, {
        guildId: guild.id,
        server: guild.name,
        analytics: store.analytics || {},
        minus: getMinusStatus ? getMinusStatus(guild.id, store) : null,
        members: members.map(item => ({
          memberId: item.memberId || '', codename: item.codename || '未設定',
          displayName: item.displayName || item.discordUsername || '不明', status: item.status || 'active',
          verifiedAt: item.verifiedAt || null, userId: item.userId || '',
        })),
      });
    } catch (error) {
      console.error('管理画面API:', error);
      return sendJson(res, 500, { error: '管理画面データを取得できません。' });
    }
  });
  controlServer.listen(port + 1, '127.0.0.1', () => console.log(`管理画面データを http://127.0.0.1:${port + 1} で配信します。`));
  controlServer.on('error', error => console.error('管理画面データAPIを起動できません:', error.message));
  return server;
}
