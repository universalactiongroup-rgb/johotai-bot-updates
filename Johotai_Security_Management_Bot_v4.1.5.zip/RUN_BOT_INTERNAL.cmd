@echo off
chcp 65001 >nul
title 情報保安対策委員会 対応記録Bot
cd /d "%~dp0"

echo ============================================================
echo  論談会・情報保安対策委員会 統合管理Bot v4.1.5
echo ============================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo [エラー] Node.js がインストールされていません。
  echo https://nodejs.org/ からLTS版をインストールしてください。
  goto :STOP
)

if not exist config.env (
  echo [エラー] config.env がありません。
  echo 先に 1_SETUP.cmd を実行してください。
  goto :STOP
)

findstr /C:"ここにBotトークンを入力" config.env >nul 2>&1
if not errorlevel 1 (
  echo [エラー] Botトークンが設定されていません。
  echo config.env を開き、DISCORD_BOT_TOKEN を設定してください。
  start "" notepad "%~dp0config.env"
  goto :STOP
)

echo 起動に必要なファイルを確認しています...
node -e "require('discord.js');require('exceljs');require('pdfkit')" >nul 2>&1
if errorlevel 1 (
  echo 不足しているファイルを自動インストールします。
  call npm install --omit=dev --loglevel=error --no-audit --no-fund
  if errorlevel 1 (
    echo [エラー] 必要なファイルのインストールに失敗しました。
    echo インターネット接続を確認して 1_SETUP.cmd を実行してください。
    goto :STOP
  )
)

echo.
echo Botを起動します。終了するときは Ctrl+C を押してください。
echo ------------------------------------------------------------
node bot-launcher.js 2^>^&1
set BOT_EXIT=%ERRORLEVEL%
echo ------------------------------------------------------------
echo [停止] Botが終了しました。終了コード: %BOT_EXIT%
echo [%DATE% %TIME%] Bot終了コード: %BOT_EXIT%>>startup-error.log

:STOP
echo.
echo この画面は自動では閉じません。
echo エラーがある場合は、この画面のスクリーンショットを撮ってください。
pause
