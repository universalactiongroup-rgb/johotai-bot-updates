import dotenv from 'dotenv';
import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  ModalBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
} from 'discord.js';
import { createWriteStream, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { once } from 'node:events';
import PDFDocument from 'pdfkit';
import ExcelJS from 'exceljs';
import { communityCommands, attachCommunityEvents, handleCommunityInteraction, runCommunityTimers } from './community.js';

dotenv.config({ path: 'config.env' });

const token = process.env.DISCORD_BOT_TOKEN?.trim();
const guildId = process.env.DISCORD_GUILD_ID?.trim();
const prefix = (process.env.CASE_PREFIX?.trim() || 'JHT').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 12) || 'JHT';
const embedColor = Number.parseInt(process.env.EMBED_COLOR || '00BCD4', 16);

if (!token || token.includes('ここに')) {
  console.error('config.env の DISCORD_BOT_TOKEN を設定してください。');
  process.exit(1);
}

const DATA_DIR = new URL('./data/', import.meta.url);
const DB_FILE = new URL('./data/database.json', import.meta.url);
const BACKUP_DIR = new URL('./data/backups/', import.meta.url);
mkdirSync(DATA_DIR, { recursive: true });
mkdirSync(BACKUP_DIR, { recursive: true });

const initialDatabase = { version: 1, guilds: {} };
let database = loadDatabase();
let writeQueue = Promise.resolve();
const pendingCreates = new Map();

function loadDatabase() {
  if (!existsSync(DB_FILE)) return structuredClone(initialDatabase);
  try {
    const value = JSON.parse(readFileSync(DB_FILE, 'utf8'));
    if (!value.guilds || typeof value.guilds !== 'object') throw new Error('guildsがありません');
    return value;
  } catch (error) {
    console.error('database.jsonを読み込めません:', error);
    process.exit(1);
  }
}

function saveDatabase() {
  writeQueue = writeQueue.then(() => {
    const temporary = new URL('./data/database.tmp.json', import.meta.url);
    writeFileSync(temporary, JSON.stringify(database, null, 2), 'utf8');
    renameSync(temporary, DB_FILE);
  });
  return writeQueue;
}

function guildStore(id) {
  database.guilds[id] ??= {
    nextNumber: 1,
    config: { channelId: null, roleId: null },
    cases: {},
  };
  return database.guilds[id];
}

const statuses = {
  received: { label: '受付済み', color: 0x00bcd4 },
  checking: { label: '確認中', color: 0xffc107 },
  responding: { label: '対応中', color: 0xff9800 },
  monitoring: { label: '経過観察', color: 0x8e44ad },
  closed: { label: '対応完了', color: 0x2ecc71 },
  cancelled: { label: '発行取消', color: 0x7f8c8d },
};

const priorities = { low: '低', normal: '通常', high: '高', urgent: '緊急' };
const confidentialityLabels = { committee: '委員会内部限り', officers: '関係役員限り', disclosable: '開示可能' };

const command = new SlashCommandBuilder()
  .setName('case')
  .setDescription('情報保安対策委員会の対応記録を管理します')
  .addSubcommand(sub => sub.setName('create').setDescription('新しい対応記録を作成します')
    .addStringOption(opt => opt.setName('priority').setDescription('緊急度').addChoices({name:'低',value:'low'},{name:'通常',value:'normal'},{name:'高',value:'high'},{name:'緊急',value:'urgent'}))
    .addStringOption(opt => opt.setName('confidentiality').setDescription('機密区分').addChoices({name:'委員会内部限り',value:'committee'},{name:'関係役員限り',value:'officers'},{name:'開示可能',value:'disclosable'}))
    .addUserOption(opt => opt.setName('member').setDescription('記録を紐付ける対象会員'))
    .addUserOption(opt => opt.setName('assignee').setDescription('担当委員'))
    .addStringOption(opt => opt.setName('deadline').setDescription('対応期限（例：2026-09-20 18:00）').setMaxLength(30)))
  .addSubcommand(sub => sub.setName('edit').setDescription('対応記録を編集します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号（例：JHT-0001）').setRequired(true)))
  .addSubcommand(sub => sub.setName('status').setDescription('対応状況を変更します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addStringOption(opt => opt.setName('status').setDescription('新しい対応状況').setRequired(true)
      .addChoices(...Object.entries(statuses).map(([value, item]) => ({ name: item.label, value })))))
  .addSubcommand(sub => sub.setName('view').setDescription('対応記録を確認します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true)))
  .addSubcommand(sub => sub.setName('list').setDescription('案件の一覧を表示します')
    .addStringOption(opt => opt.setName('status').setDescription('対応状況で絞り込みます')
      .addChoices({ name: '未完了すべて', value: 'open' }, ...Object.entries(statuses).map(([value, item]) => ({ name: item.label, value })))))
  .addSubcommand(sub => sub.setName('close').setDescription('案件を対応完了にします')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addStringOption(opt => opt.setName('note').setDescription('完了時の補足').setMaxLength(500)))
  .addSubcommand(sub => sub.setName('reopen').setDescription('完了した案件を再開します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true)))
  .addSubcommand(sub => sub.setName('history').setDescription('変更履歴を確認します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true)))
  .addSubcommand(sub => sub.setName('append').setDescription('経過・調査メモを追記します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addStringOption(opt => opt.setName('type').setDescription('追記の種類').setRequired(true).addChoices({name:'対応経過',value:'progress'},{name:'調査メモ（内部）',value:'memo'}))
    .addStringOption(opt => opt.setName('text').setDescription('追記内容').setRequired(true).setMaxLength(1000)))
  .addSubcommand(sub => sub.setName('evidence').setDescription('証拠ファイルを登録します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addAttachmentOption(opt => opt.setName('file').setDescription('証拠画像・ファイル').setRequired(true))
    .addStringOption(opt => opt.setName('description').setDescription('証拠の説明').setMaxLength(500)))
  .addSubcommand(sub => sub.setName('assign').setDescription('担当委員を割り当てます')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addUserOption(opt => opt.setName('member').setDescription('担当委員').setRequired(true)))
  .addSubcommand(sub => sub.setName('transfer').setDescription('別の委員へ引き継ぎます')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addUserOption(opt => opt.setName('member').setDescription('新しい担当委員').setRequired(true))
    .addStringOption(opt => opt.setName('note').setDescription('引継事項').setRequired(true).setMaxLength(800)))
  .addSubcommand(sub => sub.setName('deadline').setDescription('対応期限を設定・解除します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addStringOption(opt => opt.setName('date').setDescription('例：2026-09-20 18:00／clearで解除').setRequired(true).setMaxLength(30)))
  .addSubcommand(sub => sub.setName('approve').setDescription('委員会として承認・差戻しを記録します')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addStringOption(opt => opt.setName('decision').setDescription('決裁').setRequired(true).addChoices({name:'承認',value:'approved'},{name:'差戻し',value:'rejected'}))
    .addStringOption(opt => opt.setName('note').setDescription('決裁理由・補足').setMaxLength(500)))
  .addSubcommand(sub => sub.setName('cancel').setDescription('誤発行等として取消扱いにします')
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('取消理由').setRequired(true).setMaxLength(500)))
  .addSubcommand(sub => sub.setName('search').setDescription('受付番号・内容・関係者から検索します')
    .addStringOption(opt => opt.setName('query').setDescription('検索語').setRequired(true).setMaxLength(100)))
  .addSubcommand(sub => sub.setName('export').setDescription('案件をPDF・Excel・CSVで出力します')
    .addStringOption(opt => opt.setName('format').setDescription('出力形式').setRequired(true).addChoices({name:'PDF（正式記録票）',value:'pdf'},{name:'Excel（見やすい帳票）',value:'xlsx'},{name:'CSV（データ連携用）',value:'csv'}))
    .addStringOption(opt => opt.setName('case_id').setDescription('受付番号（Excel・CSVでは省略すると全件）')))
  .addSubcommand(sub => sub.setName('stats').setDescription('案件統計を表示します'))
  .addSubcommand(sub => sub.setName('backup').setDescription('全設定・記録のバックアップを取得します'))
  .addSubcommand(sub => sub.setName('panel').setDescription('操作パネルを表示します'))
  .addSubcommand(sub => sub.setName('config').setDescription('記録チャンネルと委員会役職を設定します')
    .addChannelOption(opt => opt.setName('channel').setDescription('対応記録の投稿先').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addRoleOption(opt => opt.setName('role').setDescription('コマンドを利用できる委員会役職').setRequired(true))
    .addChannelOption(opt => opt.setName('audit_channel').setDescription('監査ログの投稿先').addChannelTypes(ChannelType.GuildText)));

const client = new Client({ intents: [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMembers,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent,
  GatewayIntentBits.GuildModeration,
  GatewayIntentBits.GuildVoiceStates,
] });

const communityContext={client,guildStore,saveDatabase,audit,embedColor,hasAccess,isManager};
attachCommunityEvents(communityContext);

function normalizeId(value) {
  const raw = value.trim().toUpperCase();
  const match = raw.match(new RegExp(`^(?:${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}-?)?(\\d+)$`, 'i'));
  if (!match) return raw;
  return `${prefix}-${match[1].padStart(4, '0')}`;
}

function formatCaseId(number) {
  return `${prefix}-${String(number).padStart(4, '0')}`;
}

function clean(value, fallback = '記載なし') {
  const text = String(value ?? '').trim();
  return (text || fallback).slice(0, 1024);
}

function isManager(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild);
}

function hasAccess(interaction) {
  if (!interaction.inGuild()) return false;
  if (isManager(interaction)) return true;
  const roleId = guildStore(interaction.guildId).config.roleId;
  return Boolean(roleId && interaction.member?.roles?.cache?.has(roleId));
}

async function requireAccess(interaction) {
  if (hasAccess(interaction)) return true;
  const payload = { content: 'この機能は情報保安対策委員会の指定役職のみ利用できます。', ephemeral: true };
  if (interaction.deferred || interaction.replied) await interaction.followUp(payload);
  else await interaction.reply(payload);
  return false;
}

function findCase(guildIdValue, caseIdValue) {
  return guildStore(guildIdValue).cases[normalizeId(caseIdValue)];
}

function snapshot(item) {
  return {
    category: item.category,
    parties: item.parties,
    location: item.location,
    summary: item.summary,
    response: item.response,
    status: item.status,
    completionNote: item.completionNote || '',
    priority: item.priority || 'normal',
    confidentiality: item.confidentiality || 'committee',
    assigneeId: item.assigneeId || null,
    deadline: item.deadline || null,
    approval: item.approval || null,
  };
}

function parseDeadline(value) {
  const normalized = String(value).trim().replace(/\//g, '-');
  const parsed = new Date(normalized.includes('T') ? normalized : normalized.replace(/\s+/, 'T') + ':00+09:00');
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}

function displayDate(value) {
  if (!value) return '未設定';
  return `<t:${Math.floor(new Date(value).getTime() / 1000)}:f>`;
}

async function audit(guildIdValue, text) {
  const channelId = guildStore(guildIdValue).config.auditChannelId;
  if (!channelId) return;
  try {
    const channel = await client.channels.fetch(channelId);
    if (channel?.isTextBased()) await channel.send({ content: `🔐 ${text}`, allowedMentions: { parse: [] } });
  } catch (error) {
    console.error('監査ログの送信に失敗しました:', error.message);
  }
}

function addHistory(item, user, action, before = null) {
  item.history ??= [];
  item.history.push({
    at: new Date().toISOString(),
    userId: user.id,
    userName: user.globalName || user.username,
    action,
    before,
  });
  item.updatedAt = new Date().toISOString();
  item.updatedBy = user.id;
  item.updateCount = (item.updateCount || 0) + 1;
}

function caseEmbed(item) {
  const state = statuses[item.status] || statuses.received;
  const embed = new EmbedBuilder()
    .setColor(state.color || embedColor)
    .setTitle('情報保安対策委員会　対応記録')
    .setDescription(`**受付番号：\`${item.id}\`**`)
    .addFields(
      { name: '対応状況', value: state.label, inline: true },
      { name: '事案区分', value: clean(item.category), inline: true },
      { name: '緊急度', value: priorities[item.priority] || '通常', inline: true },
      { name: '機密区分', value: confidentialityLabels[item.confidentiality] || '委員会内部限り', inline: true },
      { name: '担当委員', value: item.assigneeId ? `<@${item.assigneeId}>` : '未割当', inline: true },
      { name: '対象会員', value: item.memberUserId ? `<@${item.memberUserId}>` : '未紐付け', inline: true },
      { name: '対応期限', value: displayDate(item.deadline), inline: true },
      { name: '対象者・関係者', value: clean(item.parties).slice(0, 850) },
      { name: '発生場所', value: clean(item.location).slice(0, 850) },
      { name: '事案の概要', value: clean(item.summary).slice(0, 850) },
      { name: '実施した対応・確認事項', value: clean(item.response).slice(0, 850) },
    )
    .setTimestamp(new Date(item.updatedAt || item.createdAt))
    .setFooter({ text: `作成者: ${item.createdByName}｜更新 ${item.updateCount || 0}回｜委員会内部限り` });
  if (item.completionNote) embed.addFields({ name: '完了時の補足', value: clean(item.completionNote).slice(0, 600) });
  if (item.approval) embed.addFields({ name: '委員会決裁', value: `${item.approval.decision === 'approved' ? '承認' : '差戻し'}｜<@${item.approval.userId}>\n${clean(item.approval.note, '補足なし').slice(0, 600)}` });
  return embed;
}

function caseComponents(item) {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`case_edit:${item.id}`).setLabel('編集').setEmoji('✏️').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`case_status:${item.id}`).setLabel('状態変更').setEmoji('🔄').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`case_history:${item.id}`).setLabel('履歴').setEmoji('📋').setStyle(ButtonStyle.Secondary),
  )];
}

function makeModal(kind, item = null) {
  const id = item?.id || 'new';
  const modal = new ModalBuilder()
    .setCustomId(`case_modal:${kind}:${id}`)
    .setTitle(kind === 'create' ? '対応記録を作成' : `${id} を編集`);
  const field = (customId, label, style, required, maxLength, value = '') => {
    const input = new TextInputBuilder().setCustomId(customId).setLabel(label).setStyle(style).setRequired(required).setMaxLength(maxLength);
    if (value) input.setValue(String(value).slice(0, maxLength));
    return new ActionRowBuilder().addComponents(input);
  };
  modal.addComponents(
    field('category', '事案区分', TextInputStyle.Short, true, 100, item?.category),
    field('parties', '対象者・関係者', TextInputStyle.Paragraph, true, 1000, item?.parties),
    field('location', '発生場所・メッセージリンク', TextInputStyle.Paragraph, false, 1000, item?.location),
    field('summary', '事案の概要', TextInputStyle.Paragraph, true, 1000, item?.summary),
    field('response', '実施した対応・確認事項', TextInputStyle.Paragraph, false, 1000, item?.response),
  );
  return modal;
}

async function updatePostedMessage(item) {
  if (!item.channelId || !item.messageId) return;
  try {
    const channel = await client.channels.fetch(item.channelId);
    if (!channel?.isTextBased()) return;
    const message = await channel.messages.fetch(item.messageId);
    await message.edit({ embeds: [caseEmbed(item)], components: caseComponents(item) });
  } catch (error) {
    console.error(`記録メッセージの更新に失敗しました (${item.id}):`, error.message);
  }
}

function csvCell(value) {
  return `"${String(value ?? '').replace(/"/g, '""').replace(/\r?\n/g, ' ')}"`;
}

function casesCsv(items) {
  const header = ['受付番号','状況','緊急度','機密区分','事案区分','対象会員ID','対象者・関係者','発生場所','概要','対応内容','担当者ID','期限','作成日時','最終更新日時'];
  const rows = items.map(item => [item.id,statuses[item.status]?.label,priorities[item.priority || 'normal'],confidentialityLabels[item.confidentiality || 'committee'],item.category,item.memberUserId,item.parties,item.location,item.summary,item.response,item.assigneeId,item.deadline,item.createdAt,item.updatedAt]);
  return '\uFEFF' + [header, ...rows].map(row => row.map(csvCell).join(',')).join('\r\n');
}

async function casePdf(item) {
  const output = new URL(`./data/${item.id}.pdf`, import.meta.url);
  const font = new URL('./node_modules/@expo-google-fonts/noto-sans-jp/400Regular/NotoSansJP_400Regular.ttf', import.meta.url);
  const doc = new PDFDocument({ size: 'A4', margin: 46, bufferPages: true, info: { Title: `${item.id} 対応記録`, Author: '情報保安対策委員会' } });
  const stream = createWriteStream(output);
  doc.pipe(stream);
  if (existsSync(font)) doc.font(font.pathname);
  const pageWidth=doc.page.width-92;
  const dateText=value=>value?new Date(value).toLocaleString('ja-JP',{timeZone:'Asia/Tokyo'}):'未設定';
  const pageHeader=()=>{
    doc.rect(46,36,pageWidth,9).fill('#00BCD4');
    doc.fontSize(9).fillColor('#52616B').text('情報保安対策委員会',46,52,{width:pageWidth});
  };
  pageHeader();
  doc.fontSize(21).fillColor('#123B4A').text('対応記録票',46,78,{width:pageWidth});
  doc.fontSize(10).fillColor('#52616B').text(`受付番号  ${item.id}`,46,110,{width:pageWidth});
  doc.moveTo(46,132).lineTo(549,132).lineWidth(1).strokeColor('#B8DDE3').stroke();
  doc.y=150;
  const summary=[
    ['対応状況',statuses[item.status]?.label||item.status],['緊急度',priorities[item.priority||'normal']],
    ['機密区分',confidentialityLabels[item.confidentiality||'committee']],['事案区分',item.category||'記載なし'],
    ['担当委員',item.assigneeId||'未割当'],['対応期限',dateText(item.deadline)],
  ];
  summary.forEach(([label,value],index)=>{
    const col=index%2,row=Math.floor(index/2),x=46+col*252,y=150+row*43;
    doc.roundedRect(x,y,240,34,3).fill('#EAF7F9');
    doc.fontSize(8).fillColor('#007C91').text(label,x+9,y+6,{width:72});
    doc.fontSize(10).fillColor('#172B34').text(String(value),x+82,y+6,{width:148,height:23,ellipsis:true});
  });
  doc.y=288;
  const section=(title,value)=>{
    const text=String(value||'記載なし');
    const height=Math.max(58,doc.heightOfString(text,{width:pageWidth-24})+38);
    if(doc.y+height>735){doc.addPage();pageHeader();doc.y=76;}
    const y=doc.y;
    doc.roundedRect(46,y,pageWidth,height,4).lineWidth(0.8).strokeColor('#B8DDE3').stroke();
    doc.rect(46,y,pageWidth,24).fill('#123B4A');
    doc.fontSize(9).fillColor('#FFFFFF').text(title,56,y+7,{width:pageWidth-20});
    doc.fontSize(10).fillColor('#172B34').text(text,58,y+33,{width:pageWidth-24,lineGap:2});
    doc.y=y+height+10;
  };
  section('対象者・関係者',item.parties);
  if(item.memberUserId)section('紐付け対象会員',`DiscordユーザーID：${item.memberUserId}`);
  section('発生場所・関連リンク',item.location);
  section('事案の概要',item.summary);
  section('実施した対応・確認事項',item.response);
  if(item.completionNote)section('完了時の補足',item.completionNote);
  if(item.approval)section('委員会決裁',`${item.approval.decision==='approved'?'承認':'差戻し'}\n${item.approval.note||'補足なし'}\n決裁者ID：${item.approval.userId}`);
  if(item.notes?.length)section('対応経過・調査メモ',item.notes.map(note=>`${dateText(note.at)}　${note.type==='memo'?'内部調査メモ':'対応経過'}\n${note.text}`).join('\n\n'));
  if(item.evidence?.length)section('証拠資料一覧',item.evidence.map((e,i)=>`${i+1}. ${e.name}\n${e.description||'説明なし'}\n${e.url}`).join('\n\n'));
  section('記録情報',`作成：${dateText(item.createdAt)}\n最終更新：${dateText(item.updatedAt)}\n作成者：${item.createdByName||item.createdBy||'不明'}　更新回数：${item.updateCount||0}回`);
  const range=doc.bufferedPageRange();
  for(let i=range.start;i<range.start+range.count;i++){
    doc.switchToPage(i);
    doc.moveTo(46,766).lineTo(549,766).lineWidth(0.5).strokeColor('#B8DDE3').stroke();
    doc.fontSize(7).fillColor('#667780').text('委員会の許可なく複製・転送・第三者への開示をしてはならない。',46,774,{width:420,lineBreak:false});
    doc.text(`${i+1} / ${range.count}`,466,774,{width:83,align:'right',lineBreak:false});
  }
  doc.end();
  await once(stream, 'finish');
  return output;
}

async function casesXlsx(items,detailItem=null){
  const workbook=new ExcelJS.Workbook();
  workbook.creator='情報保安対策委員会'; workbook.created=new Date();
  const navy='123B4A',cyan='00BCD4',pale='EAF7F9',line='B8DDE3',white='FFFFFF',text='172B34';
  const thin={style:'thin',color:{argb:line}};
  if(detailItem){
    const sheet=workbook.addWorksheet('対応記録票',{pageSetup:{paperSize:9,orientation:'portrait',fitToPage:true,fitToWidth:1,fitToHeight:0,margins:{left:0.35,right:0.35,top:0.45,bottom:0.45,header:0.2,footer:0.2}}});
    sheet.views=[{showGridLines:false}]; sheet.columns=[{width:4},{width:18},{width:25},{width:18},{width:25},{width:4}];
    sheet.mergeCells('B2:E2'); sheet.getCell('B2').value='情報保安対策委員会　対応記録票';
    sheet.getCell('B2').font={name:'Yu Gothic',size:16,bold:true,color:{argb:navy}}; sheet.getCell('B2').alignment={vertical:'middle'}; sheet.getRow(2).height=30;
    sheet.mergeCells('B3:E3'); sheet.getCell('B3').value=`受付番号　${detailItem.id}`; sheet.getCell('B3').font={name:'Yu Gothic',size:10,color:{argb:'52616B'}};
    const pairs=[['対応状況',statuses[detailItem.status]?.label],['緊急度',priorities[detailItem.priority||'normal']],['機密区分',confidentialityLabels[detailItem.confidentiality||'committee']],['事案区分',detailItem.category||'記載なし'],['担当委員ID',detailItem.assigneeId||'未割当'],['対応期限',detailItem.deadline?new Date(detailItem.deadline):'未設定']];
    let row=5; for(let i=0;i<pairs.length;i+=2){for(let c=0;c<2;c++){const p=pairs[i+c],label=sheet.getCell(row,2+c*2),value=sheet.getCell(row,3+c*2);label.value=p[0];value.value=p[1];label.fill={type:'pattern',pattern:'solid',fgColor:{argb:navy}};label.font={name:'Yu Gothic',bold:true,color:{argb:white}};value.fill={type:'pattern',pattern:'solid',fgColor:{argb:pale}};[label,value].forEach(cell=>{cell.border={top:thin,left:thin,bottom:thin,right:thin};cell.alignment={vertical:'middle',wrapText:true};});}sheet.getRow(row).height=28;row++;}
    const sections=[['対象者・関係者',detailItem.parties],['発生場所・関連リンク',detailItem.location],['事案の概要',detailItem.summary],['実施した対応・確認事項',detailItem.response],['完了時の補足',detailItem.completionNote||'なし'],['委員会決裁',detailItem.approval?`${detailItem.approval.decision==='approved'?'承認':'差戻し'}\n${detailItem.approval.note||'補足なし'}`:'未決裁'],['対応経過・調査メモ',(detailItem.notes||[]).map(n=>`${new Date(n.at).toLocaleString('ja-JP')}　${n.type==='memo'?'内部調査メモ':'対応経過'}\n${n.text}`).join('\n\n')||'なし'],['証拠資料',(detailItem.evidence||[]).map((e,i)=>`${i+1}. ${e.name}\n${e.description||'説明なし'}\n${e.url}`).join('\n\n')||'なし']];
    row+=1; for(const [label,value] of sections){sheet.mergeCells(row,2,row,5);const h=sheet.getCell(row,2);h.value=label;h.fill={type:'pattern',pattern:'solid',fgColor:{argb:navy}};h.font={name:'Yu Gothic',bold:true,color:{argb:white}};h.alignment={vertical:'middle'};sheet.getRow(row).height=23;row++;sheet.mergeCells(row,2,row,5);const b=sheet.getCell(row,2);b.value=value||'記載なし';b.font={name:'Yu Gothic',size:10,color:{argb:text}};b.alignment={vertical:'top',wrapText:true};b.border={top:thin,left:thin,bottom:thin,right:thin};sheet.getRow(row).height=Math.min(120,Math.max(38,String(value||'').split('\n').length*16));row+=2;}
    sheet.mergeCells(row,2,row,5);sheet.getCell(row,2).value=`作成：${new Date(detailItem.createdAt).toLocaleString('ja-JP')}　　最終更新：${new Date(detailItem.updatedAt).toLocaleString('ja-JP')}　　更新回数：${detailItem.updateCount||0}回`;sheet.getCell(row,2).font={name:'Yu Gothic',size:8,color:{argb:'667780'}};
    sheet.headerFooter.oddFooter='委員会の許可なく複製・転送・第三者への開示をしてはならない。　　　　　　　　　&P / &N';
    sheet.pageSetup.printArea=`B2:E${row}`;
  }
  const list=workbook.addWorksheet('案件一覧',{views:[{state:'frozen',ySplit:3,showGridLines:false}]});
  list.columns=[{header:'受付番号',key:'id',width:15},{header:'対応状況',key:'status',width:13},{header:'緊急度',key:'priority',width:10},{header:'機密区分',key:'confidentiality',width:18},{header:'事案区分',key:'category',width:18},{header:'対象者・関係者',key:'parties',width:24},{header:'事案の概要',key:'summary',width:42},{header:'担当委員ID',key:'assignee',width:22},{header:'対応期限',key:'deadline',width:20},{header:'作成日時',key:'created',width:20},{header:'最終更新日時',key:'updated',width:20}];
  list.spliceRows(1,0,['情報保安対策委員会　対応記録一覧']); list.mergeCells('A1:K1'); list.getCell('A1').font={name:'Yu Gothic',size:16,bold:true,color:{argb:navy}};list.getRow(1).height=30;list.spliceRows(2,0,[`出力日時：${new Date().toLocaleString('ja-JP')}　　全${items.length}件`]);list.mergeCells('A2:K2');list.getCell('A2').font={name:'Yu Gothic',size:9,color:{argb:'52616B'}};
  list.getRow(3).values=['受付番号','対応状況','緊急度','機密区分','事案区分','対象者・関係者','事案の概要','担当委員ID','対応期限','作成日時','最終更新日時'];
  for(const item of items)list.addRow([item.id,statuses[item.status]?.label||item.status,priorities[item.priority||'normal'],confidentialityLabels[item.confidentiality||'committee'],item.category,item.parties,item.summary,item.assigneeId||'未割当',item.deadline?new Date(item.deadline):null,new Date(item.createdAt),new Date(item.updatedAt)]);
  list.autoFilter={from:'A3',to:'K3'};list.getRow(3).height=26;list.getRow(3).eachCell(cell=>{cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:navy}};cell.font={name:'Yu Gothic',bold:true,color:{argb:white}};cell.alignment={horizontal:'center',vertical:'middle'};cell.border={bottom:thin};});
  for(let r=4;r<=list.rowCount;r++){list.getRow(r).height=32;list.getRow(r).eachCell(cell=>{cell.font={name:'Yu Gothic',size:9,color:{argb:text}};cell.alignment={vertical:'top',wrapText:true};cell.border={bottom:{style:'hair',color:{argb:line}}};});if(r%2===0)list.getRow(r).eachCell(cell=>cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:'F4FAFB'}});const status=list.getCell(r,2);const color=status.value==='対応完了'?'DFF3E4':status.value==='発行取消'?'ECEFF1':status.value==='対応中'?'FFF0D9':'EAF7F9';status.fill={type:'pattern',pattern:'solid',fgColor:{argb:color}};list.getCell(r,9).numFmt='yyyy/mm/dd hh:mm';list.getCell(r,10).numFmt='yyyy/mm/dd hh:mm';list.getCell(r,11).numFmt='yyyy/mm/dd hh:mm';}
  list.pageSetup={paperSize:9,orientation:'landscape',fitToPage:true,fitToWidth:1,fitToHeight:0,printTitlesRow:'1:3'};
  const output=new URL(`./data/${detailItem?detailItem.id:'JHT-all'}.xlsx`,import.meta.url);
  await workbook.xlsx.writeFile(output.pathname);return output;
}

async function postThread(item, content, files = []) {
  const targetId = item.threadId || item.channelId;
  const channel = await client.channels.fetch(targetId);
  if (channel?.isTextBased()) await channel.send({ content, files, allowedMentions: { users: item.assigneeId ? [item.assigneeId] : [] } });
}

function autoBackup() {
  const day = new Date().toISOString().slice(0, 10);
  const output = new URL(`./data/backups/database-${day}.json`, import.meta.url);
  if (!existsSync(output)) writeFileSync(output, JSON.stringify(database, null, 2), 'utf8');
}

async function checkDeadlines() {
  const now=Date.now();
  for(const [guildIdValue,store] of Object.entries(database.guilds)){
    for(const item of Object.values(store.cases||{})){
      if(!item.deadline||item.reminderSent||['closed','cancelled'].includes(item.status))continue;
      const remaining=new Date(item.deadline).getTime()-now;
      if(remaining<=24*60*60*1000){
        const late=remaining<0;
        await postThread(item,`⏰ **対応期限${late?'超過':'のお知らせ'}**\n${item.id} の期限は ${displayDate(item.deadline)} です。${item.assigneeId?`\n担当委員：<@${item.assigneeId}>`:''}`).catch(()=>{});
        await audit(guildIdValue,`${item.id} の対応期限${late?'が超過しました':'が24時間以内です'}。`);
        item.reminderSent=true;
        addHistory(item,{id:client.user.id,username:client.user.username},late?'期限超過を通知':'期限前通知を送信');
        await saveDatabase();
      }
    }
  }
}

async function handleCommand(interaction) {
  const sub = interaction.options.getSubcommand();
  const store = guildStore(interaction.guildId);

  if (sub === 'config') {
    if (!isManager(interaction)) return interaction.reply({ content: '設定には「サーバー管理」権限が必要です。', ephemeral: true });
    const channel = interaction.options.getChannel('channel', true);
    const role = interaction.options.getRole('role', true);
    const auditChannel = interaction.options.getChannel('audit_channel');
    store.config = { channelId: channel.id, roleId: role.id, auditChannelId: auditChannel?.id || store.config.auditChannelId || null };
    await saveDatabase();
    return interaction.reply({ content: `設定しました。\n記録チャンネル：${channel}\n委員会役職：${role}\n監査ログ：${auditChannel || '未設定'}`, ephemeral: true });
  }

  if (!(await requireAccess(interaction))) return;
  if (!store.config.channelId) return interaction.reply({ content: '先に管理者が `/case config` を実行してください。', ephemeral: true });

  if (sub === 'create') {
    const deadlineText = interaction.options.getString('deadline');
    const deadline = deadlineText ? parseDeadline(deadlineText) : null;
    if (deadlineText && !deadline) return interaction.reply({ content: '期限を読み取れません。例：`2026-09-20 18:00`', ephemeral: true });
    const key = `${interaction.guildId}-${interaction.user.id}`;
    pendingCreates.set(key, {
      priority: interaction.options.getString('priority') || 'normal',
      confidentiality: interaction.options.getString('confidentiality') || 'committee',
      assigneeId: interaction.options.getUser('assignee')?.id || null,
      memberUserId: interaction.options.getUser('member')?.id || null,
      deadline,
    });
    return interaction.showModal(makeModal('create'));
  }

  if (sub === 'list') {
    const filter = interaction.options.getString('status') || 'open';
    let items = Object.values(store.cases).sort((a, b) => b.number - a.number);
    items = filter === 'open' ? items.filter(item => !['closed', 'cancelled'].includes(item.status)) : items.filter(item => item.status === filter);
    const lines = items.slice(0, 25).map(item => `**\`${item.id}\`**　${statuses[item.status]?.label || item.status}｜${clean(item.category, '未分類')}\n${clean(item.summary).slice(0, 80)}`);
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(embedColor).setTitle('対応記録一覧').setDescription(lines.join('\n\n') || '該当する記録はありません。').setFooter({ text: items.length > 25 ? `全${items.length}件のうち最新25件を表示` : `${items.length}件` })], ephemeral: true });
  }

  if (sub === 'search') {
    const query = interaction.options.getString('query', true).toLowerCase();
    const items = Object.values(store.cases).filter(item => JSON.stringify(item).toLowerCase().includes(query)).sort((a,b) => b.number-a.number);
    const lines = items.slice(0, 20).map(item => `**\`${item.id}\`** ${statuses[item.status]?.label}｜${clean(item.summary).slice(0, 100)}`);
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(embedColor).setTitle(`検索結果：「${query}」`).setDescription(lines.join('\n\n') || '一致する記録はありません。').setFooter({text:`${items.length}件`})], ephemeral: true });
  }

  if (sub === 'stats') {
    const items = Object.values(store.cases);
    const byStatus = Object.entries(statuses).map(([key,value]) => `${value.label}：${items.filter(item=>item.status===key).length}件`).join('\n');
    const byPriority = Object.entries(priorities).map(([key,value]) => `${value}：${items.filter(item=>(item.priority||'normal')===key).length}件`).join('\n');
    const month = new Date().toISOString().slice(0,7);
    return interaction.reply({ embeds:[new EmbedBuilder().setColor(embedColor).setTitle('対応記録 統計').addFields({name:'総件数',value:`${items.length}件`,inline:true},{name:'今月の受付',value:`${items.filter(item=>item.createdAt?.startsWith(month)).length}件`,inline:true},{name:'対応状況',value:byStatus},{name:'緊急度',value:byPriority}).setTimestamp()], ephemeral:true });
  }

  if (sub === 'backup') {
    if (!isManager(interaction)) return interaction.reply({content:'バックアップの取得には「サーバー管理」権限が必要です。',ephemeral:true});
    const buffer = Buffer.from(JSON.stringify({version:database.version,guilds:{[interaction.guildId]:store}},null,2),'utf8');
    await audit(interaction.guildId, `${interaction.user.tag} がデータバックアップを取得しました。`);
    return interaction.reply({content:'機密データを含みます。安全な場所で保管してください。',files:[new AttachmentBuilder(buffer,{name:`jht-backup-${new Date().toISOString().slice(0,10)}.json`})],ephemeral:true});
  }

  if (sub === 'panel') {
    const embed = new EmbedBuilder().setColor(embedColor).setTitle('情報保安対策委員会　操作パネル').setDescription('案件の作成は `/case create` を使用してください。\n下のボタンから一覧・統計をすぐに確認できます。');
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('case_panel_open').setLabel('未完了一覧').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('case_panel_stats').setLabel('統計').setStyle(ButtonStyle.Secondary),
    );
    return interaction.reply({embeds:[embed],components:[row],ephemeral:true});
  }

  if (sub === 'export') {
    const format = interaction.options.getString('format',true);
    const requestedId = interaction.options.getString('case_id');
    if (format === 'pdf' && !requestedId) return interaction.reply({content:'PDF出力では受付番号を指定してください。',ephemeral:true});
    if (format === 'csv') {
      const items = requestedId ? [findCase(interaction.guildId,requestedId)].filter(Boolean) : Object.values(store.cases).sort((a,b)=>a.number-b.number);
      if (!items.length) return interaction.reply({content:'出力できる記録がありません。',ephemeral:true});
      await audit(interaction.guildId, `${interaction.user.tag} が${requestedId ? normalizeId(requestedId) : '全案件'}をCSV出力しました。`);
      return interaction.reply({content:'CSVを作成しました。',files:[new AttachmentBuilder(Buffer.from(casesCsv(items),'utf8'),{name:`${requestedId?normalizeId(requestedId):'JHT-all'}.csv`})],ephemeral:true});
    }
    if (format === 'xlsx') {
      const selected=requestedId?findCase(interaction.guildId,requestedId):null;
      if(requestedId&&!selected)return interaction.reply({content:'指定された受付番号が見つかりません。',ephemeral:true});
      const items=selected?[selected]:Object.values(store.cases).sort((a,b)=>a.number-b.number);
      if(!items.length)return interaction.reply({content:'出力できる記録がありません。',ephemeral:true});
      await interaction.deferReply({ephemeral:true});
      const output=await casesXlsx(items,selected);
      await audit(interaction.guildId,`${interaction.user.tag} が${selected?selected.id:'全案件'}をExcel出力しました。`);
      return interaction.editReply({content:selected?'対応記録票と案件一覧をExcelで作成しました。':'案件一覧をExcelで作成しました。',files:[new AttachmentBuilder(output.pathname,{name:`${selected?selected.id:'JHT-all'}.xlsx`})]});
    }
    const selected = findCase(interaction.guildId,requestedId);
    if (!selected) return interaction.reply({content:'指定された受付番号が見つかりません。',ephemeral:true});
    await interaction.deferReply({ephemeral:true});
    const output = await casePdf(selected);
    await audit(interaction.guildId, `${interaction.user.tag} が${selected.id}をPDF出力しました。`);
    return interaction.editReply({content:'PDFを作成しました。',files:[new AttachmentBuilder(output.pathname,{name:`${selected.id}.pdf`})]});
  }

  const caseId = interaction.options.getString('case_id', true);
  const item = findCase(interaction.guildId, caseId);
  if (!item) return interaction.reply({ content: `受付番号「${normalizeId(caseId)}」は見つかりません。`, ephemeral: true });

  if (sub === 'edit') return interaction.showModal(makeModal('edit', item));
  if (sub === 'view') return interaction.reply({ embeds: [caseEmbed(item)], components: caseComponents(item), ephemeral: true });
  if (sub === 'history') return showHistory(interaction, item);

  if (sub === 'append') {
    const type = interaction.options.getString('type',true);
    const text = interaction.options.getString('text',true);
    item.notes ??= [];
    item.notes.push({type,text,at:new Date().toISOString(),userId:interaction.user.id});
    addHistory(item,interaction.user,type==='memo'?'内部調査メモを追記':'対応経過を追記');
    await saveDatabase();
    if(type==='progress') await postThread(item,`📝 **対応経過**｜<@${interaction.user.id}>\n${text}`);
    await audit(interaction.guildId,`${interaction.user.tag} が ${item.id} に${type==='memo'?'内部メモ':'対応経過'}を追記しました。`);
    return interaction.reply({content:`${item.id} に${type==='memo'?'内部調査メモ':'対応経過'}を追記しました。`,ephemeral:true});
  }

  if (sub === 'evidence') {
    const file = interaction.options.getAttachment('file',true);
    const description = interaction.options.getString('description')||'説明なし';
    item.evidence ??= [];
    item.evidence.push({name:file.name,url:file.url,contentType:file.contentType,size:file.size,description,at:new Date().toISOString(),userId:interaction.user.id});
    addHistory(item,interaction.user,`証拠ファイル「${file.name}」を登録`);
    await saveDatabase();
    await postThread(item,`📎 **証拠資料を登録**｜<@${interaction.user.id}>\n説明：${description}\nファイル：${file.url}`);
    await audit(interaction.guildId,`${interaction.user.tag} が ${item.id} に証拠ファイルを登録しました。`);
    return interaction.reply({content:`${item.id} に「${file.name}」を登録しました。`,ephemeral:true});
  }

  if (sub === 'assign' || sub === 'transfer') {
    const member = interaction.options.getUser('member',true);
    const before = snapshot(item);
    item.assigneeId = member.id;
    item.reminderSent = false;
    const note = sub==='transfer'?interaction.options.getString('note',true):'';
    addHistory(item,interaction.user,sub==='transfer'?`${member.tag}へ引継ぎ：${note}`:`${member.tag}を担当に割当`,before);
    await saveDatabase(); await updatePostedMessage(item);
    await postThread(item,`👤 **${sub==='transfer'?'担当引継ぎ':'担当割当'}**\n新担当：<@${member.id}>${note?`\n引継事項：${note}`:''}`);
    return interaction.reply({content:`${item.id} の担当を ${member} に設定しました。`,ephemeral:true});
  }

  if (sub === 'deadline') {
    const value=interaction.options.getString('date',true);
    const deadline=value.toLowerCase()==='clear'?null:parseDeadline(value);
    if(value.toLowerCase()!=='clear'&&!deadline)return interaction.reply({content:'期限を読み取れません。例：`2026-09-20 18:00` または `clear`',ephemeral:true});
    const before=snapshot(item); item.deadline=deadline; item.reminderSent=false;
    addHistory(item,interaction.user,deadline?`期限を${deadline}に設定`:'期限を解除',before);
    await saveDatabase(); await updatePostedMessage(item);
    return interaction.reply({content:`${item.id} の期限を${deadline?displayDate(deadline):'解除'}しました。`,ephemeral:true});
  }

  if (sub === 'approve') {
    const decision=interaction.options.getString('decision',true); const note=interaction.options.getString('note')||'';
    item.approval={decision,note,userId:interaction.user.id,at:new Date().toISOString()};
    addHistory(item,interaction.user,decision==='approved'?'委員会承認':'委員会差戻し');
    await saveDatabase(); await updatePostedMessage(item);
    await postThread(item,`✅ **委員会決裁：${decision==='approved'?'承認':'差戻し'}**｜<@${interaction.user.id}>\n${note||'補足なし'}`);
    return interaction.reply({content:`${item.id} の決裁を記録しました。`,ephemeral:true});
  }

  if (sub === 'cancel') {
    const reason=interaction.options.getString('reason',true); const before=snapshot(item);
    item.status='cancelled'; item.completionNote=`取消理由：${reason}`;
    addHistory(item,interaction.user,`発行取消：${reason}`,before);
    await saveDatabase(); await updatePostedMessage(item);
    await audit(interaction.guildId,`${interaction.user.tag} が ${item.id} を発行取消にしました。`);
    return interaction.reply({content:`${item.id} を発行取消として記録しました。番号は再利用されません。`,ephemeral:true});
  }

  if (sub === 'status') {
    const nextStatus = interaction.options.getString('status', true);
    const before = snapshot(item);
    item.status = nextStatus;
    addHistory(item, interaction.user, `対応状況を「${statuses[nextStatus].label}」へ変更`, before);
    await saveDatabase();
    await updatePostedMessage(item);
    return interaction.reply({ content: `${item.id} の対応状況を「${statuses[nextStatus].label}」へ変更しました。`, ephemeral: true });
  }

  if (sub === 'close' || sub === 'reopen') {
    const before = snapshot(item);
    item.status = sub === 'close' ? 'closed' : 'responding';
    if (sub === 'close') item.completionNote = interaction.options.getString('note')?.trim() || item.completionNote || '';
    addHistory(item, interaction.user, sub === 'close' ? '案件を対応完了' : '案件を再開', before);
    await saveDatabase();
    await updatePostedMessage(item);
    return interaction.reply({ content: `${item.id} を${sub === 'close' ? '対応完了にしました' : '再開しました'}。`, ephemeral: true });
  }
}

async function handleModal(interaction) {
  if (!(await requireAccess(interaction))) return;
  const [, kind, id] = interaction.customId.split(':');
  const store = guildStore(interaction.guildId);
  const values = Object.fromEntries(['category', 'parties', 'location', 'summary', 'response'].map(key => [key, interaction.fields.getTextInputValue(key).trim()]));

  if (kind === 'create') {
    await interaction.deferReply({ ephemeral: true });
    const pendingKey = `${interaction.guildId}-${interaction.user.id}`;
    const extra = pendingCreates.get(pendingKey) || { priority: 'normal', confidentiality: 'committee', assigneeId: null, deadline: null };
    pendingCreates.delete(pendingKey);
    const number = store.nextNumber++;
    const caseId = formatCaseId(number);
    const now = new Date().toISOString();
    const item = {
      id: caseId,
      number,
      status: 'received',
      ...extra,
      ...values,
      completionNote: '',
      approval: null,
      evidence: [],
      notes: [],
      reminderSent: false,
      createdAt: now,
      createdBy: interaction.user.id,
      createdByName: interaction.user.globalName || interaction.user.username,
      updatedAt: now,
      updatedBy: interaction.user.id,
      updateCount: 0,
      channelId: store.config.channelId,
      messageId: null,
      threadId: null,
      history: [{ at: now, userId: interaction.user.id, userName: interaction.user.globalName || interaction.user.username, action: '対応記録を作成', before: null }],
    };
    store.cases[caseId] = item;
    await saveDatabase();
    try {
      const channel = await client.channels.fetch(store.config.channelId);
      if (!channel?.isTextBased()) throw new Error('設定されたチャンネルへ投稿できません');
      const message = await channel.send({ embeds: [caseEmbed(item)], components: caseComponents(item) });
      item.messageId = message.id;
      item.channelId = message.channelId;
      try {
        const thread = await message.startThread({ name: `${caseId}｜${String(values.category).slice(0, 60)}`, autoArchiveDuration: 10080, reason: `${caseId} 対応記録` });
        item.threadId = thread.id;
        await thread.send({content:`このスレッドは **${caseId}** の証拠資料・対応経過・引継事項を集約します。${item.assigneeId?`\n担当委員：<@${item.assigneeId}>`:''}`,allowedMentions:{users:item.assigneeId?[item.assigneeId]:[]}});
      } catch (error) {
        console.error(`スレッド作成に失敗しました (${caseId}):`,error.message);
      }
      await saveDatabase();
      await audit(interaction.guildId,`${interaction.user.tag} が ${caseId} を作成しました。`);
      return interaction.editReply(`対応記録を作成しました。\n受付番号：**${caseId}**\n記録：${message.url}`);
    } catch (error) {
      console.error(error);
      return interaction.editReply(`受付番号 **${caseId}** は発行されましたが、記録チャンネルへの投稿に失敗しました。権限と設定を確認してください。番号は再利用されません。`);
    }
  }

  const item = store.cases[id];
  if (!item) return interaction.reply({ content: '編集対象の記録が見つかりません。', ephemeral: true });
  const before = snapshot(item);
  Object.assign(item, values);
  addHistory(item, interaction.user, '記録内容を編集', before);
  await saveDatabase();
  await updatePostedMessage(item);
  return interaction.reply({ content: `${item.id} を更新しました。`, ephemeral: true });
}

async function showHistory(interaction, item) {
  const rows = (item.history || []).slice(-15).reverse().map(entry => {
    const unix = Math.floor(new Date(entry.at).getTime() / 1000);
    return `<t:${unix}:f>｜${String(entry.action).slice(0,180)}\n更新者：<@${entry.userId}>`;
  });
  const payload = { embeds: [new EmbedBuilder().setColor(embedColor).setTitle(`${item.id}　変更履歴`).setDescription(rows.join('\n\n') || '履歴はありません。').setFooter({ text: `全${item.history?.length || 0}件・最新15件まで表示` })], ephemeral: true };
  if (interaction.deferred || interaction.replied) return interaction.followUp(payload);
  return interaction.reply(payload);
}

async function handleButton(interaction) {
  if (!(await requireAccess(interaction))) return;
  if (interaction.customId === 'case_panel_open') {
    const items=Object.values(guildStore(interaction.guildId).cases).filter(item=>!['closed','cancelled'].includes(item.status)).sort((a,b)=>b.number-a.number);
    const lines=items.slice(0,20).map(item=>`**\`${item.id}\`** ${statuses[item.status]?.label}｜${clean(item.summary).slice(0,90)}`);
    return interaction.reply({embeds:[new EmbedBuilder().setColor(embedColor).setTitle('未完了案件').setDescription(lines.join('\n\n')||'未完了案件はありません。')],ephemeral:true});
  }
  if (interaction.customId === 'case_panel_stats') {
    const items=Object.values(guildStore(interaction.guildId).cases);
    const text=Object.entries(statuses).map(([key,value])=>`${value.label}：${items.filter(item=>item.status===key).length}件`).join('\n');
    return interaction.reply({embeds:[new EmbedBuilder().setColor(embedColor).setTitle('対応記録 統計').setDescription(`総件数：${items.length}件\n\n${text}`)],ephemeral:true});
  }
  const [action, id] = interaction.customId.split(':');
  const item = guildStore(interaction.guildId).cases[id];
  if (!item) return interaction.reply({ content: '対象の記録が見つかりません。', ephemeral: true });
  if (action === 'case_edit') return interaction.showModal(makeModal('edit', item));
  if (action === 'case_history') return showHistory(interaction, item);
  if (action === 'case_status') {
    const menu = new StringSelectMenuBuilder().setCustomId(`case_status_select:${id}`).setPlaceholder('新しい対応状況を選択').addOptions(
      Object.entries(statuses).map(([value, state]) => ({ label: state.label, value, default: item.status === value })),
    );
    return interaction.reply({ content: `**${id}** の新しい対応状況を選択してください。`, components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
  }
}

async function handleSelect(interaction) {
  if (!(await requireAccess(interaction))) return;
  const id = interaction.customId.split(':')[1];
  const item = guildStore(interaction.guildId).cases[id];
  if (!item) return interaction.update({ content: '対象の記録が見つかりません。', components: [] });
  const nextStatus = interaction.values[0];
  const before = snapshot(item);
  item.status = nextStatus;
  addHistory(item, interaction.user, `対応状況を「${statuses[nextStatus].label}」へ変更`, before);
  await saveDatabase();
  await updatePostedMessage(item);
  return interaction.update({ content: `${id} の対応状況を「${statuses[nextStatus].label}」へ変更しました。`, components: [] });
}

client.once(Events.ClientReady, async ready => {
  console.log(`${ready.user.tag} としてログインしました。`);
  try {
    if (guildId) {
      const guild = await client.guilds.fetch(guildId);
      await guild.commands.set([command.toJSON(),...communityCommands.map(item=>item.toJSON())]);
      console.log(`サーバー「${guild.name}」へ /case を登録しました。`);
    } else {
      await client.application.commands.set([command.toJSON(),...communityCommands.map(item=>item.toJSON())]);
      console.log('グローバルコマンド /case を登録しました。反映に時間がかかる場合があります。');
    }
  } catch (error) {
    console.error('コマンド登録に失敗しました:', error);
  }
  autoBackup();
  await checkDeadlines();
  setInterval(checkDeadlines,15*60*1000);
  setInterval(autoBackup,60*60*1000);
  runCommunityTimers(communityContext);
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand() && interaction.commandName === 'case') await handleCommand(interaction);
    else if (interaction.isChatInputCommand() && communityCommands.some(item=>item.name===interaction.commandName)) await handleCommunityInteraction(interaction,communityContext);
    else if (interaction.isModalSubmit() && interaction.customId.startsWith('case_modal:')) await handleModal(interaction);
    else if (interaction.isModalSubmit() && interaction.customId==='verify_register') await handleCommunityInteraction(interaction,communityContext);
    else if (interaction.isButton() && interaction.customId.startsWith('case_')) await handleButton(interaction);
    else if (interaction.isButton() && /^(verify|ticket|rolepanel|event|apply):/.test(interaction.customId)) await handleCommunityInteraction(interaction,communityContext);
    else if (interaction.isStringSelectMenu() && interaction.customId.startsWith('case_status_select:')) await handleSelect(interaction);
  } catch (error) {
    console.error('操作の処理中にエラーが発生しました:', error);
    const payload = { content: '処理中にエラーが発生しました。Botの画面を確認してください。', ephemeral: true };
    if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(() => {});
    else await interaction.reply(payload).catch(() => {});
  }
});

process.on('unhandledRejection', error => console.error('未処理エラー:', error));
process.on('uncaughtException', error => console.error('重大なエラー:', error));

if (process.env.DRY_RUN === 'true') {
  console.log(`コマンド定義を検証しました（${JSON.stringify([command.toJSON(),...communityCommands.map(item=>item.toJSON())]).length} bytes）。`);
  if (process.env.DRY_RUN_PDF === 'true') {
    const testItem={id:'JHT-0001',number:1,status:'received',priority:'high',confidentiality:'committee',category:'情報漏えい',parties:'テスト対象者',location:'#対応記録',summary:'日本語帳票出力の動作確認を行うためのサンプル案件です。',response:'表示、改ページ、文字化け、罫線を確認しました。',assigneeId:'123456789012345678',deadline:new Date(Date.now()+86400000).toISOString(),completionNote:'継続確認中',notes:[{type:'progress',text:'関係者への聞き取りを実施しました。',at:new Date().toISOString()}],evidence:[{name:'evidence.png',description:'確認用画像',url:'https://example.invalid/evidence.png'}],createdByName:'坂田隆憲',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),updateCount:2};
    console.log(`PDFを検証しました：${(await casePdf(testItem)).pathname}`);
    console.log(`Excelを検証しました：${(await casesXlsx([testItem],testItem)).pathname}`);
  }
} else {
  client.login(token);
}
