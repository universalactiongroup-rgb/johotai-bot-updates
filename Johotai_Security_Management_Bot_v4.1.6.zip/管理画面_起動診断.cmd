@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 情報保安対策委員会 Bot - 管理画面起動診断
echo 管理画面を診断モードで起動します。
echo.
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Launch-ControlPanel.ps1"
echo.
echo 終了コード: %ERRORLEVEL%
echo 起動できなかった場合は gui-error.log も確認してください。
pause
