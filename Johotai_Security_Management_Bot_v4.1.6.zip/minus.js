import {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, EmbedBuilder, ModalBuilder,
  PermissionFlagsBits, SlashCommandBuilder, TextInputBuilder, TextInputStyle,
} from 'discord.js';
import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';

const DATA_DIR = new URL('./data/', import.meta.url);
const CONTACT_FILE = new URL('./data/emergency-contacts.json', import.meta.url);
const CONTACT_TMP = new URL('./data/emergency-contacts.tmp.json', import.meta.url);
const pendingReconsents = new Map();
mkdirSync(DATA_DIR, { recursive: true });

export const minusCommand = new SlashCommandBuilder()
  .setName('minus').setDescription('マイナスチャンネルの同意・緊急連絡先を管理します')
  .addSubcommand(s => s.setName('config').setDescription('マイナスチャンネル機能を設定します')
    .addRoleOption(o => o.setName('access_role').setDescription('同意後に付与する利用役職').setRequired(true))
    .addRoleOption(o => o.setName('committee_role').setDescription('緊急連絡先を閲覧できる委員会役職').setRequired(true))
    .addChannelOption(o => o.setName('audit_channel').setDescription('監査ログチャンネル').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addChannelOption(o => o.setName('minus_channel').setDescription('マイナステキストチャンネル').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addStringOption(o => o.setName('rules_url').setDescription('保護管理規程のHTTPS URL').setRequired(true).setMaxLength(500)))
  .addSubcommand(s => s.setName('panel').setDescription('利用同意パネルを投稿します'))
  .addSubcommand(s => s.setName('contact').setDescription('緊急連絡先を閲覧します')
    .addUserOption(o => o.setName('user').setDescription('対象者').setRequired(true)))
  .addSubcommand(s => s.setName('contact-delete').setDescription('緊急連絡先を削除します')
    .addUserOption(o => o.setName('user').setDescription('対象者').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('削除理由').setRequired(true).setMaxLength(500)))
  .addSubcommand(s => s.setName('my-contact-delete').setDescription('自分の緊急連絡先を削除します'))
  .addSubcommand(s => s.setName('revoke').setDescription('利用権限を撤回します')
    .addUserOption(o => o.setName('user').setDescription('対象者').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('撤回理由').setRequired(true).setMaxLength(500)))
  .addSubcommand(s => s.setName('require-reconsent').setDescription('規程改定に伴い全利用者へ再同意を求めます')
    .addStringOption(o => o.setName('version').setDescription('新しい規程バージョン').setRequired(true).setMaxLength(50)));

function config(store) {
  store.minus ??= { config: null, rulesVersion: '初版', consents: {} };
  store.minus.consents ??= {};
  return store.minus;
}

function loadContacts() {
  if (!existsSync(CONTACT_FILE)) return { version: 1, guilds: {} };
  try {
    const value = JSON.parse(readFileSync(CONTACT_FILE, 'utf8'));
    if (!value.guilds || typeof value.guilds !== 'object') throw new Error();
    return value;
  } catch { throw new Error('緊急連絡先データを安全に読み込めません。管理者へ連絡してください。'); }
}

function saveContacts(value) {
  writeFileSync(CONTACT_TMP, JSON.stringify(value, null, 2), { encoding: 'utf8', mode: 0o600 });
  renameSync(CONTACT_TMP, CONTACT_FILE);
}

function encryptionKey() {
  const source = process.env.EMERGENCY_DATA_KEY?.trim();
  if (!source) return null;
  try {
    const raw = Buffer.from(source, 'base64');
    if (raw.length < 32 || raw.toString('base64').replace(/=+$/,'') !== source.replace(/=+$/,'')) return null;
    return createHash('sha256').update(raw).digest();
  } catch { return null; }
}

function encrypt(value) {
  const key = encryptionKey();
  if (!key) throw new Error('管理者が EMERGENCY_DATA_KEY を設定していないため登録できません。');
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()]);
  return { algorithm: 'aes-256-gcm', iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), ciphertext: ciphertext.toString('base64') };
}

function decrypt(envelope) {
  const key = encryptionKey();
  if (!key) throw new Error('暗号鍵が未設定または不正なため閲覧できません。');
  try {
    if (envelope?.algorithm !== 'aes-256-gcm') throw new Error();
    const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(envelope.iv, 'base64'));
    decipher.setAuthTag(Buffer.from(envelope.tag, 'base64'));
    return JSON.parse(Buffer.concat([decipher.update(Buffer.from(envelope.ciphertext, 'base64')), decipher.final()]).toString('utf8'));
  } catch { throw new Error('緊急連絡先を復号できません。暗号鍵が登録時と同じか確認してください。'); }
}

function manager(i) { return i.memberPermissions?.has(PermissionFlagsBits.ManageGuild); }
function contactOfficer(i, cfg) { return Boolean(cfg?.committeeRoleId && (manager(i) || i.member?.roles?.cache?.has(cfg.committeeRoleId))); }
async function answer(i, payload) { payload.ephemeral ??= true; return i.deferred || i.replied ? i.followUp(payload) : i.reply(payload); }
function time(value) { return new Date(value).toLocaleString('ja-JP', { timeZone: 'Asia/Tokyo' }); }

async function audit(ctx, guildId, title, lines, color = 0x00bcd4) {
  const cfg = config(ctx.guildStore(guildId)).config;
  if (!cfg?.auditChannelId) return;
  const channel = await ctx.client.channels.fetch(cfg.auditChannelId).catch(() => null);
  if (!channel?.isTextBased()) return;
  await channel.send({ embeds: [new EmbedBuilder().setColor(color).setTitle(title).setDescription(lines.join('\n').slice(0, 4000)).setTimestamp()] }).catch(() => {});
}

function contactModal() {
  return new ModalBuilder().setCustomId('minus:contact-modal').setTitle('緊急連絡先の登録・更新').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('緊急連絡先氏名').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('relationship').setLabel('本人との関係（例：保護者・家族）').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('phone').setLabel('緊急連絡先電話番号').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(30)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('selfContact').setLabel('本人の連絡先（任意）').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('consent').setLabel('同意する場合「同意します」と入力').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(10)),
  );
}

async function agree(i, ctx, minus) {
  const cfg = minus.config;
  if (!cfg?.accessRoleId) return answer(i, { content: '管理者がマイナスチャンネル利用役職を設定していません。' });
  const current = minus.consents[i.user.id];
  if (current?.status === 'agreed' && current.rulesVersion === minus.rulesVersion) return answer(i, { content: '既に現在の規程へ同意済みです。' });
  const role = await i.guild.roles.fetch(cfg.accessRoleId).catch(() => null);
  const member = await i.guild.members.fetch(i.user.id).catch(() => null);
  if (!role || !member) return answer(i, { content: '利用役職または会員情報を取得できません。管理者へ連絡してください。' });
  if (!i.guild.members.me?.permissions.has(PermissionFlagsBits.ManageRoles) || i.guild.members.me.roles.highest.comparePositionTo(role) <= 0)
    return answer(i, { content: 'Botの役職が利用役職より上位にないため付与できません。サーバー設定の「ロール」でBot役職を上へ移動してください。' });
  await member.roles.add(role, `マイナスチャンネル規程 ${minus.rulesVersion} へ同意`);
  const now = new Date().toISOString();
  minus.consents[i.user.id] = { userId: i.user.id, status: 'agreed', rulesVersion: minus.rulesVersion, agreedAt: now, updatedAt: now };
  await ctx.saveDatabase();
  await audit(ctx, i.guildId, 'マイナスチャンネル規程へ同意', [`対象者：<@${i.user.id}> (${i.user.id})`, `規程バージョン：${minus.rulesVersion}`], 0x2ecc71);
  return answer(i, { content: `規程（${minus.rulesVersion}）への同意を記録し、利用役職を付与しました。` });
}

async function saveContact(i, ctx) {
  if (i.fields.getTextInputValue('consent').trim() !== '同意します') return answer(i, { content: '「同意します」と完全一致しないため保存しませんでした。' });
  if (!encryptionKey()) return answer(i, { content: '管理者が EMERGENCY_DATA_KEY を設定していないため登録できません。' });
  const contacts = loadContacts();
  contacts.guilds[i.guildId] ??= {};
  const previous = contacts.guilds[i.guildId][i.user.id];
  const now = new Date().toISOString();
  const payload = {
    name: i.fields.getTextInputValue('name').trim(), relationship: i.fields.getTextInputValue('relationship').trim(),
    phone: i.fields.getTextInputValue('phone').trim(), selfContact: i.fields.getTextInputValue('selfContact').trim(),
  };
  contacts.guilds[i.guildId][i.user.id] = { userId: i.user.id, registeredAt: previous?.registeredAt || now, updatedAt: now, encrypted: encrypt(payload) };
  saveContacts(contacts);
  await audit(ctx, i.guildId, previous ? '緊急連絡先を更新' : '緊急連絡先を登録', [`対象者：<@${i.user.id}> (${i.user.id})`, '個人情報本文は監査ログへ記録していません。'], 0xf39c12);
  return answer(i, { content: '緊急連絡先の登録内容を更新しました。' });
}

async function deleteContact(i, ctx, userId, reason, self = false) {
  const contacts = loadContacts();
  const existed = Boolean(contacts.guilds[userId === i.user.id ? i.guildId : i.guildId]?.[userId]);
  if (!existed) return answer(i, { content: '登録された緊急連絡先はありません。' });
  delete contacts.guilds[i.guildId][userId];
  saveContacts(contacts);
  await audit(ctx, i.guildId, '緊急連絡先を削除', [`対象者：<@${userId}> (${userId})`, `実行者：<@${i.user.id}> (${i.user.id})`, `理由：${self ? '本人による削除' : reason}`, '削除した個人情報本文は記録していません。'], 0xe74c3c);
  return answer(i, { content: self ? '自分の緊急連絡先を削除しました。' : '対象者の緊急連絡先を削除しました。' });
}

async function requireReconsent(i, ctx, minus, version) {
  const role = minus.config?.accessRoleId ? await i.guild.roles.fetch(minus.config.accessRoleId).catch(() => null) : null;
  let removed = 0;
  for (const [userId, record] of Object.entries(minus.consents)) {
    record.status = 'reconsent_required'; record.updatedAt = new Date().toISOString();
    if (role) { const member = await i.guild.members.fetch(userId).catch(() => null); if (member?.roles.cache.has(role.id)) { await member.roles.remove(role, `規程 ${version} への再同意待ち`).catch(() => {}); removed += 1; } }
  }
  minus.rulesVersion = version;
  await ctx.saveDatabase();
  await audit(ctx, i.guildId, '規程の再同意を要求', [`新規程バージョン：${version}`, `実行者：<@${i.user.id}> (${i.user.id})`, `対象：${Object.keys(minus.consents).length}名`, `役職剥奪：${removed}名`], 0xe67e22);
  return answer(i, { content: `規程バージョンを「${version}」へ変更し、${Object.keys(minus.consents).length}名を再同意待ちにしました。利用役職は${removed}名から剥奪しました。` });
}

export async function handleMinusInteraction(i, ctx) {
  const minus = config(ctx.guildStore(i.guildId));
  if (i.isModalSubmit()) return saveContact(i, ctx);
  if (i.isButton()) {
    if (i.customId === 'minus:agree') return agree(i, ctx, minus);
    if (i.customId === 'minus:contact') return i.showModal(contactModal());
    if (i.customId === 'minus:delete-own') return deleteContact(i, ctx, i.user.id, '', true);
    if (i.customId.startsWith('minus:reconsent:')) {
      if (!manager(i)) return answer(i, { content: '実行権限がありません。' });
      const token = i.customId.slice('minus:reconsent:'.length), pending = pendingReconsents.get(token);
      if (!pending || pending.guildId !== i.guildId || pending.userId !== i.user.id || pending.expiresAt < Date.now()) return answer(i, { content: '確認操作の有効期限が切れました。コマンドをもう一度実行してください。' });
      pendingReconsents.delete(token);
      return requireReconsent(i, ctx, minus, pending.version);
    }
  }
  const sub = i.options.getSubcommand();
  if (sub === 'config') {
    if (!manager(i)) return answer(i, { content: '設定には「サーバー管理」権限が必要です。' });
    const rulesUrl = i.options.getString('rules_url', true).trim();
    if (!rulesUrl.startsWith('https://')) return answer(i, { content: '規程URLにはHTTPSの公開URLを指定してください。' });
    minus.config = { accessRoleId: i.options.getRole('access_role', true).id, committeeRoleId: i.options.getRole('committee_role', true).id, auditChannelId: i.options.getChannel('audit_channel', true).id, minusChannelId: i.options.getChannel('minus_channel', true).id, rulesUrl };
    await ctx.saveDatabase();
    return answer(i, { content: `設定しました。\n利用役職：<@&${minus.config.accessRoleId}>\n委員会役職：<@&${minus.config.committeeRoleId}>\n監査ログ：<#${minus.config.auditChannelId}>\nマイナスチャンネル：<#${minus.config.minusChannelId}>` });
  }
  if (sub === 'panel') {
    if (!manager(i)) return answer(i, { content: 'パネル投稿には「サーバー管理」権限が必要です。' });
    if (!minus.config) return answer(i, { content: '先に `/minus config` を実行してください。' });
    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('minus:agree').setLabel('規程に同意して利用する').setEmoji('✅').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('minus:contact').setLabel('緊急連絡先を登録する（任意）').setEmoji('🆘').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('minus:delete-own').setLabel('緊急連絡先を削除する').setEmoji('🗑️').setStyle(ButtonStyle.Danger),
    );
    const links = new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('保護管理規程を確認').setStyle(ButtonStyle.Link).setURL(minus.config.rulesUrl));
    await i.channel.send({ embeds: [new EmbedBuilder().setColor(ctx.embedColor).setTitle('マイナステキストチャンネル利用同意').setDescription('マイナステキストチャンネルを利用するには、先に「マイナスチャンネル保護管理規程」を確認してください。\n\n同意ボタンを押すと、規程・監視体制・秘密保持・緊急時対応・違反時の措置に同意したものとして、利用役職が付与されます。\n\n緊急連絡先の登録は任意です。').addFields({ name: '規程バージョン', value: minus.rulesVersion })], components: [buttons, links] });
    return answer(i, { content: '利用同意パネルを投稿しました。' });
  }
  if (sub === 'my-contact-delete') return deleteContact(i, ctx, i.user.id, '', true);
  if (sub === 'contact' || sub === 'contact-delete') {
    if (!minus.config?.committeeRoleId) return answer(i, { content: '緊急連絡先閲覧用の委員会役職が未設定のため使用できません。' });
    if (!contactOfficer(i, minus.config)) return answer(i, { content: '指定された情報保安対策委員会役職または「サーバー管理」権限が必要です。' });
    const user = i.options.getUser('user', true);
    if (sub === 'contact-delete') return deleteContact(i, ctx, user.id, i.options.getString('reason', true));
    const contacts = loadContacts(), record = contacts.guilds[i.guildId]?.[user.id];
    if (!record) return answer(i, { content: '対象者の緊急連絡先は登録されていません。' });
    let data;
    try { data = decrypt(record.encrypted); }
    catch (error) { await audit(ctx, i.guildId, '緊急連絡先の復号失敗', [`対象者：<@${user.id}> (${user.id})`, `実行者：<@${i.user.id}> (${i.user.id})`, '個人情報本文は記録していません。'], 0xe74c3c); throw error; }
    await audit(ctx, i.guildId, '緊急連絡先を閲覧・復号', [`対象者：<@${user.id}> (${user.id})`, `閲覧者：<@${i.user.id}> (${i.user.id})`, '個人情報本文は記録していません。'], 0xf39c12);
    return answer(i, { embeds: [new EmbedBuilder().setColor(0xe67e22).setTitle(`${user.username} の緊急連絡先`).addFields(
      { name: '氏名', value: data.name }, { name: '本人との関係', value: data.relationship, inline: true },
      { name: '電話番号', value: data.phone, inline: true }, { name: '本人の連絡先', value: data.selfContact || '未登録' },
      { name: '登録日時', value: time(record.registeredAt), inline: true }, { name: '更新日時', value: time(record.updatedAt), inline: true },
    ).setFooter({ text: 'エフェメラル表示・取扱注意' })] });
  }
  if (sub === 'revoke') {
    if (!manager(i)) return answer(i, { content: '実行には「サーバー管理」権限が必要です。' });
    if (!minus.config?.accessRoleId) return answer(i, { content: '利用役職が未設定です。' });
    const user = i.options.getUser('user', true), reason = i.options.getString('reason', true), member = await i.guild.members.fetch(user.id).catch(() => null);
    if (member) await member.roles.remove(minus.config.accessRoleId, reason).catch(() => {});
    const now = new Date().toISOString();
    minus.consents[user.id] = { ...(minus.consents[user.id] || { userId: user.id }), status: 'revoked', revokedAt: now, revokedBy: i.user.id, revokeReason: reason, updatedAt: now };
    await ctx.saveDatabase();
    await audit(ctx, i.guildId, 'マイナスチャンネル利用権限を撤回', [`対象者：<@${user.id}> (${user.id})`, `実行者：<@${i.user.id}> (${i.user.id})`, `理由：${reason}`], 0xe74c3c);
    return answer(i, { content: '利用役職を剥奪し、同意状態を撤回済みに変更しました。緊急連絡先は削除していません。' });
  }
  if (sub === 'require-reconsent') {
    if (!manager(i)) return answer(i, { content: '実行には「サーバー管理」権限が必要です。' });
    const version = i.options.getString('version', true);
    const token = randomBytes(12).toString('hex');
    pendingReconsents.set(token, { guildId: i.guildId, userId: i.user.id, version, expiresAt: Date.now() + 5 * 60 * 1000 });
    return answer(i, { content: `全利用者を再同意待ちにし、利用役職を剥奪します。新しい規程バージョン：**${version}**\n本当に実行しますか？`, components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`minus:reconsent:${token}`).setLabel('再同意を要求する').setStyle(ButtonStyle.Danger))] });
  }
}

export function getMinusStatus(guildId, store) {
  const minus = config(store), contacts = loadContacts();
  const records = Object.values(minus.consents);
  return { enabled: Boolean(minus.config), keyConfigured: Boolean(encryptionKey()), agreed: records.filter(r => r.status === 'agreed').length, contacts: Object.keys(contacts.guilds[guildId] || {}).length, reconsent: records.filter(r => r.status === 'reconsent_required').length };
}

export function runMinusCryptoSelfTest() {
  const sample = { name: 'テスト連絡先', relationship: 'テスト', phone: '000-0000-0000', selfContact: '' };
  const restored = decrypt(encrypt(sample));
  return JSON.stringify(restored) === JSON.stringify(sample);
}
