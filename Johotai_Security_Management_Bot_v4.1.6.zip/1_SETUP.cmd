@echo off
cd /d "%~dp0"
start "" wscript.exe "%~dp0START_BOT.vbs"
exit /b 0
