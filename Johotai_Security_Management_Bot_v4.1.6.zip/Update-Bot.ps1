﻿param(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [Parameter(Mandatory=$true)][string]$InstallDir,
  [int]$WaitPid = 0
)
$ErrorActionPreference = 'Stop'
if ($WaitPid -gt 0) { Wait-Process -Id $WaitPid -ErrorAction SilentlyContinue }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $InstallDir "data\update-backups\$stamp"
$stage = Join-Path $env:TEMP "JohotaiBotUpdate-$stamp"
New-Item -ItemType Directory -Force -Path $backup,$stage | Out-Null
Get-ChildItem $InstallDir -Force | Where-Object { $_.Name -notin @('node_modules','data','config.env','startup-error.log','bot-output.log') } | Copy-Item -Destination $backup -Recurse -Force
Expand-Archive -LiteralPath $ZipPath -DestinationPath $stage -Force
$source = $stage
$children = @(Get-ChildItem $stage -Force)
if ($children.Count -eq 1 -and $children[0].PSIsContainer) { $source = $children[0].FullName }
if (-not (Test-Path (Join-Path $source 'package.json'))) { throw '更新ZIPにpackage.jsonがありません。' }
Get-ChildItem $source -Force | Where-Object { $_.Name -notin @('node_modules','data','config.env') } | Copy-Item -Destination $InstallDir -Recurse -Force
Remove-Item $stage -Recurse -Force
Start-Process wscript.exe -ArgumentList ('"' + (Join-Path $InstallDir 'START_BOT.vbs') + '"')
