import { spawn } from 'node:child_process';

const startedAt = new Date();
console.log(`[起動監視] ${startedAt.toLocaleString('ja-JP')} にBotを起動します。`);
console.log(`[起動監視] Node.js ${process.version} / ${process.platform} ${process.arch}`);

const child = spawn(process.execPath, ['bot.js'], {
  cwd: process.cwd(),
  env: process.env,
  windowsHide: true,
  stdio: ['ignore', 'pipe', 'pipe'],
});

child.stdout.on('data', chunk => process.stdout.write(chunk));
child.stderr.on('data', chunk => process.stderr.write(chunk));

child.on('error', error => {
  console.error('[起動監視] Botプロセスを開始できませんでした:', error);
  process.exitCode = 1;
});

child.on('exit', (code, signal) => {
  const seconds = Math.max(0, Math.round((Date.now() - startedAt.getTime()) / 1000));
  console.error(`[起動監視] Botが終了しました。終了コード=${code ?? '不明'} シグナル=${signal ?? 'なし'} 稼働時間=${seconds}秒`);
  if (seconds < 10) console.error('[起動監視] 起動直後の終了です。上に表示されたエラーを確認してください。');
  process.exitCode = Number.isInteger(code) ? code : 1;
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    if (!child.killed) child.kill(signal);
  });
}
