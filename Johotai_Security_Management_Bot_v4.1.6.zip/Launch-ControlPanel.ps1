﻿$ErrorActionPreference = 'Stop'
try {
  & (Join-Path $PSScriptRoot 'ControlPanel.ps1')
} catch {
  $message = $_.Exception.Message
  $details = ($_ | Out-String)
  $log = Join-Path $PSScriptRoot 'gui-error.log'
  $details | Out-File -FilePath $log -Encoding UTF8
  try {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show("管理画面を起動できませんでした。`n`n$message`n`n詳細：$log", '情報保安対策委員会 Bot', 'OK', 'Error') | Out-Null
  } catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("管理画面を起動できませんでした。`r`n`r`n$message`r`n`r`n詳細：$log", '情報保安対策委員会 Bot') | Out-Null
  }
}
