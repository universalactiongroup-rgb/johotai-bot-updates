@echo off
chcp 65001 >nul
title 情報保安対策委員会 Bot - 招待
set /p CLIENT_ID=Discord Developer PortalのApplication IDを入力してください: 
if "%CLIENT_ID%"=="" exit /b 1
start "" "https://discord.com/oauth2/authorize?client_id=%CLIENT_ID%&permissions=1494917180630&integration_type=0&scope=bot+applications.commands"
echo 招待ページを開きました。
pause
