============================================================
 情報保安対策委員会 総合管理Bot v3.4.0
============================================================

【必要なもの】
・Windows 10 / 11
・Node.js 20以上（LTS推奨）
・Discord Botのトークン

【導入手順・管理画面】
古い版へ上書きせず、ZIPを新しいフォルダーへ展開してください。v3は二重フォルダーになりません。
1. Discord Developer Portalの「Bot」を開きます。
2. Privileged Gateway Intentsの「SERVER MEMBERS INTENT」と「MESSAGE CONTENT INTENT」を有効にします。
3. 3_INVITE_BOT.cmd を実行してBotをサーバーへ招待します。
4. 2_START_BOT.cmd をダブルクリックして管理画面を開きます。
5. 管理画面へBotトークン等を入力し「Botを起動」を押します。
   Node.jsや必要ファイルがなければ初回起動時に自動インストールします。
   以後の設定、起動、停止、ログ確認、更新確認も管理画面で行えます。
7. Discordで次のコマンドを実行します。
   /case config channel:#対応記録 role:@情報保安対策委員会

【コマンド】
/case create     新しい対応記録を作成します。
/case edit       Botが投稿した記録を編集します。
/case status     対応状況を変更します。
/case view       受付番号を指定して記録を表示します。
/case list       案件の一覧を表示します。
/case close      対応を完了します。
/case reopen     完了した案件を再開します。
/case history    変更履歴を表示します。
/case append     対応経過または内部調査メモを追記します。
/case evidence   証拠画像・ファイルを登録します。
/case assign     担当委員を割り当てます。
/case transfer   担当委員と引継事項を記録します。
/case deadline   対応期限を設定・解除します。
/case approve    委員会の承認・差戻しを記録します。
/case cancel     誤発行等を取消扱いにします。
/case search     受付番号・関係者・本文を横断検索します。
/case export     PDF・Excel・CSVを出力します。
/case stats      対応状況・緊急度の統計を表示します。
/case backup     サーバーの全データを取得します（管理者限定）。
/case panel      操作パネルを表示します。
/case config     記録チャンネルと委員会役職を設定します。

【総合管理コマンド】
/settings        機能ごとの有効・無効と設定確認
/automod         連投、大量メンション、招待リンク、禁止語の自動規制
/security        短時間の大量参加検知
/mod             警告、タイムアウト、Kick、BAN、解除、履歴、取消
/logs            編集・削除・参加・退出・BAN・チャンネル・VCログ
/welcome         ウェルカムメッセージ、本人確認、認証役職
/member          会員登録、プロフィール、内部メモ、対応歴
/role            ボタン式セルフ役職
/ticket          非公開相談窓口、終了、HTML会話記録
/announce        埋め込み告知、投票
/event           参加・未定・不参加ボタン付きイベント
/tools           ユーザー、サーバー、アバター、リマインダー
/faq             キーワードによる自動応答
/apply           各種申請の提出、編集、審査、決裁、履歴、PDF出力

【本人確認・会員自動登録】
「確認して登録へ進む」ボタンを押すと、Discord上にコードネームと所属を入力する画面が開きます。
送信後、MEM-0001形式の会員番号発行、会員情報登録、本人確認日時の記録、認証役職付与を自動で行います。
同じコードネームの重複登録はできません。再度本人確認した場合は既存の会員番号を維持して登録情報を更新します。

【会員モニター・Discordアクティビティ】
Windows管理画面の「会員モニター」タブに、会員番号、コードネーム、Discord表示名、状態、本人確認日時を表示します。Botの記録更新を約2秒ごとに反映します。
Discord上のBotアクティビティには、登録会員数、未完了案件数、審査中申請数を順番に表示します。

【Discord Embedded Activity：情保対モニター】
WordleやYouTube Watch Togetherと同じ形式で、Discord内に管理画面を開けます。
登録会員数、未完了案件数、審査中申請数、Bot稼働時間を5秒ごとに更新します。
画面全体を /case config で指定した委員会役職、またはサーバー管理権限を持つ人だけに表示します。
Activityは外部から到達できる固定HTTPSが必要です。詳しい設定は 4_ACTIVITY_SETUP.txt を参照してください。
Cloudflare Tunnel Tokenを管理画面へ入力すると、必要なcloudflaredを自動導入してBotと同時にHTTPS接続を起動します。
v3.3.1以降は、Bot起動時にDiscordのActivity用「起動」コマンドを自動確認し、削除・破損している場合は自動復旧します。
v3.3.2では、管理画面の「無料Activity接続」ボタンから、アカウント・ドメイン・トークン不要のCloudflare Quick Tunnelを起動できます。表示されたホスト名をDiscord Developer PortalのURL Mappingsへ貼り付けてください。
v3.3.3では、既に起動中のBotを新しい管理画面から自動検出し、ログファイル使用中エラーを防止します。
v3.3.4では、PCのCPU形式を自動判定し、壊れた・非対応のcloudflaredを自動交換します。
v3.3.5では、パッケージ導入中の経過時間を管理画面に表示し、10分で安全に中止します。Cloudflareはwingetを経由せず公式ファイルを直接取得します。
v3.4.0では、Windows管理センターとDiscord Activityの画面を刷新し、今日・今月・今年のメッセージ数、オンライン・オフライン人数、会員ごとの接続状態を追加しました。メッセージ数はv3.4.0導入後から日本時間で自動集計されます。

【申請機能】
管理者が最初に次を実行します。
/apply config channel:#申請審査 reviewer_role:@情報保安対策委員会 approvals:1

会員は /apply create で申請します。申請番号はAPP-0001から自動採番され、日付ではリセットされません。
対応種類：役職、委員会加入、人事、会員情報、本人確認、チャンネル、討議室、イベント、告知、Bot、異議申立て、記録訂正、個人情報、証拠閲覧、独自許可、表彰、提携、その他。
審査役職は投稿された「担当する」「承認」「詳細」ボタン、または /apply review・approve・reject・return を使用できます。
申請者は /apply view・list・edit・cancel・history を使用できます。決裁結果はDMでも通知されます。
役職申請は承認完了時に希望役職を自動付与します。Botの役職を付与対象役職より上へ配置してください。
/apply export は、申請内容と審査履歴をレイアウト済みPDFとして出力します。

【最初に行う推奨設定】
/case config channel:#対応記録 role:@情報保安対策委員会 audit_channel:#監査ログ
/logs config channel:#サーバーログ
/welcome config channel:#ようこそ member_role:@会員
/ticket config category:相談窓口 staff_role:@情報保安対策委員会 log_channel:#チケットログ
/security config join_limit:6 alert_channel:#緊急警報
/apply config channel:#申請審査 reviewer_role:@情報保安対策委員会 approvals:1
/settings module name:automod enabled:true

【権限について】
Botの役職は、Botが付与する役職より上に配置してください。
Kick、BAN、タイムアウト、役職付与、チケット作成、ログ取得に必要な権限を招待時に要求します。
管理コマンドは、Discord側のサーバー管理・モデレーション権限でも制限されます。

【受付番号】
JHT-0001からBotが自動で通し番号を発行します。
日付や年度ではリセットされません。取消・削除した番号も再利用しません。

【編集】
記録メッセージの「編集」ボタン、または /case edit を使います。
受付番号は変更できません。編集前の内容は履歴として保存されます。

【案件スレッド】
新規記録の投稿時に専用スレッドを自動作成します。
証拠資料、対応経過、担当変更、引継ぎ、決裁、期限通知を集約します。

【期限通知】
期限の24時間前以降に一度、自動通知します。期限超過時も通知します。
期限を変更すると通知状態がリセットされます。

【機密・監査】
作成時に機密区分と緊急度を指定できます。
/case config の audit_channel を設定すると、作成・取消・出力・バックアップ等を監査ログへ記録します。

【出力】
PDF：指定案件を、見出し・情報欄・本文欄・ページ番号を備えた正式記録票として出力します。
Excel：指定案件は「対応記録票」と「案件一覧」の二シート、全件出力は「案件一覧」として出力します。配色、罫線、列幅、折り返し、固定見出し、フィルター、印刷設定を含みます。
CSV：外部システムとのデータ連携用です。CSV自体には配色や罫線などのレイアウトを保存できません。

【自動バックアップ】
一日一回、data/backupsフォルダーへデータを保存します。
管理者は /case backup でいつでもバックアップを取得できます。

【遠隔アップデート】
管理画面の「更新情報URL」へ、HTTPSで公開した更新マニフェストJSONのURLを設定します。
公式更新URL：https://raw.githubusercontent.com/universalactiongroup-rgb/johotai-bot-updates/main/update-manifest.json
形式は同梱の update-manifest.example.json を参照してください。更新ZIPのSHA256は必須です。
「更新を確認」を押すと、新しいバージョンのみダウンロードしてハッシュを検証し、config.envとdataを保持したまま更新します。
更新前のプログラムは data/update-backups フォルダーへ保存されます。

【保存場所】
data/database.json に設定・記録・履歴を保存します。
このフォルダーを定期的にバックアップしてください。
Botの稼働中にdatabase.jsonを直接編集しないでください。

【重要】
・config.env、dataフォルダー、ログを第三者へ渡さないでください。
・記録チャンネルは委員会役職だけが閲覧できるよう設定してください。
・Botには記録チャンネルの閲覧、送信、履歴閲覧権限が必要です。

【起動できない場合】
管理画面下部のログと startup-error.log を確認してください。
管理画面自体が表示されない場合は「管理画面_起動診断.cmd」を実行してください。エラー画面とgui-error.logが残ります。
従来のコマンド画面で詳しく確認する場合だけ RUN_BOT_INTERNAL.cmd を使用できます。
